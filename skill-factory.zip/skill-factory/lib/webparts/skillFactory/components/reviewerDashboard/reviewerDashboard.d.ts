import * as React from "react";
declare class ReviewerDashboard extends React.Component {
    render(): JSX.Element;
}
export default ReviewerDashboard;
//# sourceMappingURL=reviewerDashboard.d.ts.map