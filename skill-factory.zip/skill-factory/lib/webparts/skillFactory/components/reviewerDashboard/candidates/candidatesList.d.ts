import * as React from "react";
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
declare class CandidatesListSlider extends React.Component {
    render(): JSX.Element;
}
export default CandidatesListSlider;
//# sourceMappingURL=candidatesList.d.ts.map