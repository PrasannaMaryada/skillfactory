import * as React from "react";
declare class CurrentAssignments extends React.Component {
    render(): JSX.Element;
}
export default CurrentAssignments;
//# sourceMappingURL=assignments.d.ts.map