declare const styles: {
    skillFactory: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=SkillFactory.module.scss.d.ts.map