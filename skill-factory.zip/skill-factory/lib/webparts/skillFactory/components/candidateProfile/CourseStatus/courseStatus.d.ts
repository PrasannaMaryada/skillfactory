import * as React from "react";
import "./courseStatus.css";
declare class CourseStatus extends React.Component<any, any> {
    constructor(props: any);
    OnclickInprogressBtn: () => void;
    OnclickCompletedBtn: () => void;
    render(): JSX.Element;
}
export default CourseStatus;
//# sourceMappingURL=courseStatus.d.ts.map