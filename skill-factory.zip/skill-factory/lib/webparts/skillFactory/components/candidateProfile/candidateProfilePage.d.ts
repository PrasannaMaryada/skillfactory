import * as React from 'react';
import './candidateProfilePage.css';
declare class CandidateProfilePage extends React.Component<any, any> {
    render(): JSX.Element;
}
export default CandidateProfilePage;
//# sourceMappingURL=candidateProfilePage.d.ts.map