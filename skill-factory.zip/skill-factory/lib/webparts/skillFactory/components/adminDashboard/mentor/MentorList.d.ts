import * as React from "react";
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
declare class MentorListSlider extends React.Component {
    render(): JSX.Element;
}
export default MentorListSlider;
//# sourceMappingURL=MentorList.d.ts.map