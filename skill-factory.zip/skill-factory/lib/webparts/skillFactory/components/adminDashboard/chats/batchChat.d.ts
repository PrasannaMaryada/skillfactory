export default BatchChart;
declare class BatchChart extends React.Component<any, any, any> {
    constructor(props: any);
}
import * as React from "react";
//# sourceMappingURL=batchChat.d.ts.map