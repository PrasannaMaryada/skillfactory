import * as React from "react";
declare class NewJoiners extends React.Component {
    render(): JSX.Element;
}
export default NewJoiners;
//# sourceMappingURL=newJoiners.d.ts.map