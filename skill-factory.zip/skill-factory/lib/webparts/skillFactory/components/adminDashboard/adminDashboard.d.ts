import * as React from "react";
declare class AdminDashboard extends React.Component {
    render(): JSX.Element;
}
export default AdminDashboard;
//# sourceMappingURL=adminDashboard.d.ts.map