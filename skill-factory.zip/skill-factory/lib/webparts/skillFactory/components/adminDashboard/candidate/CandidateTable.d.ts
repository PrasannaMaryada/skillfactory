import * as React from "react";
declare class CandidateTable extends React.Component {
    render(): JSX.Element;
}
export default CandidateTable;
//# sourceMappingURL=CandidateTable.d.ts.map