import * as React from "react";
declare class Welcome extends React.Component {
    render(): JSX.Element;
}
export default Welcome;
//# sourceMappingURL=welcome.d.ts.map