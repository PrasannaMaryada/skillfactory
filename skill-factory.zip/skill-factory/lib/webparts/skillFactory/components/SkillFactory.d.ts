import * as React from "react";
import { ISkillFactoryProps } from "./ISkillFactoryProps";
import "bootstrap/dist/css/bootstrap.min.css";
import "./shared/globalStyle.css";
export default class SkillFactory extends React.Component<ISkillFactoryProps, {}> {
    render(): React.ReactElement<ISkillFactoryProps>;
}
//# sourceMappingURL=SkillFactory.d.ts.map