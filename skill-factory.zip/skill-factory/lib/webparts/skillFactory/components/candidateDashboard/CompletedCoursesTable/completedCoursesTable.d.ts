import * as React from 'react';
import './completedCoursesTable.css';
declare class CompletedCoursesTable extends React.Component<any, any> {
    constructor(props: any);
    render(): JSX.Element;
}
export default CompletedCoursesTable;
//# sourceMappingURL=completedCoursesTable.d.ts.map