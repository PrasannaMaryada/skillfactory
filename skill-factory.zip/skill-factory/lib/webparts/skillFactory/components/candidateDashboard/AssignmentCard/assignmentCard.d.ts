import * as React from 'react';
import './assignmentCard.css';
declare class AssignmentCard extends React.Component<any, any> {
    constructor(props: any);
    render(): JSX.Element;
}
export default AssignmentCard;
//# sourceMappingURL=assignmentCard.d.ts.map