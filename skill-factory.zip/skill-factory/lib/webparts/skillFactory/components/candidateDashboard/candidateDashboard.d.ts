import * as React from "react";
declare class CandidateDashboard extends React.Component {
    render(): JSX.Element;
}
export default CandidateDashboard;
//# sourceMappingURL=candidateDashboard.d.ts.map