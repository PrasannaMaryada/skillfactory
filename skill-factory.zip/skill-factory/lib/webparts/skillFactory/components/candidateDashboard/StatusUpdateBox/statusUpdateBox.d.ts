import * as React from "react";
import "./statusUpdateBox.css";
declare class StatusUpdateBox extends React.Component {
    render(): JSX.Element;
}
export default StatusUpdateBox;
//# sourceMappingURL=statusUpdateBox.d.ts.map