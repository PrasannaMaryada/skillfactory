import * as React from 'react';
import './reviewList.css';
declare class ReviewList extends React.Component<any, any> {
    constructor(props: any);
    render(): JSX.Element;
}
export default ReviewList;
//# sourceMappingURL=reviewList.d.ts.map