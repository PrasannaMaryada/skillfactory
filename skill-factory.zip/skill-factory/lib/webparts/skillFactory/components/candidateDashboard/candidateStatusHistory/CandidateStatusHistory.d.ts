import * as React from 'react';
declare type modelState = {
    showHide: boolean;
    status: String;
};
export default class CandidateStatusHistory extends React.Component<{}, modelState> {
    state: {
        showHide: boolean;
        status: string;
    };
    handleShowModal: () => void;
    handleChange: (event: any) => void;
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=CandidateStatusHistory.d.ts.map