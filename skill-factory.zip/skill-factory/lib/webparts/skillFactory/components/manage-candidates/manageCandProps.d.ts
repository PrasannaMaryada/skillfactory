export interface manageCandiProps {
    leftPanelData: string;
}
//# sourceMappingURL=manageCandProps.d.ts.map