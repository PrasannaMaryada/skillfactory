import * as React from "react";
interface IProps {
}
interface IState {
    List?: {
        [x: string]: any;
        id: number;
        name: string;
        icon: string;
        skills: string;
        CC: number;
        mentor_id: number;
    }[];
    MasterChecked?: boolean;
    SelectedList?: {
        [x: string]: any;
        id: number;
        name: string;
        icon: string;
        skills: string;
        CC: number;
        mentor_id: number;
    }[];
}
declare class ManageCandidates extends React.Component<IProps, IState> {
    constructor(props: IProps);
    onMasterCheck(e: any): void;
    onItemCheck(e: any, item: any): void;
    render(): JSX.Element;
}
export default ManageCandidates;
//# sourceMappingURL=manageCandidates.d.ts.map