import * as React from "react";
import "./courseCard.css";
declare class CourseCard extends React.Component<any> {
    constructor(props: any);
    render(): JSX.Element;
}
export default CourseCard;
//# sourceMappingURL=courseCard.d.ts.map