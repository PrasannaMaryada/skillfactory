import * as React from "react";
declare class LeftPanel extends React.Component {
    render(): JSX.Element;
}
export default LeftPanel;
//# sourceMappingURL=leftpanel.d.ts.map