import * as React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import LeftPanel from "../shared/leftpanel/leftpanel";
import CandidatesListSlider from "./candidates/candidatesList";
import CurrentAssignments from "./currentassignment/assignments";

class ReviewerDashboard extends React.Component {
  render() {
    return (
      <Container fluid={true}>
        <Row>
          <Col sm={3} bsPrefix="leftPanel col">
            <LeftPanel />
          </Col>
          <Col sm={9}>
            <div className="rightContainer">
              <h3>Good Morning  Nihar !</h3>
              <Row>
                <Col sm={12}>
                <CandidatesListSlider />
                <CurrentAssignments />
                </Col>                
              </Row>              
            </div>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default ReviewerDashboard;
