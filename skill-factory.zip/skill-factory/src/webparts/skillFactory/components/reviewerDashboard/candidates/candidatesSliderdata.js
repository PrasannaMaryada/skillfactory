const CandidatesSliderdata = [
    {
        id : 1,
        active: true,
        name: "John",
        icon: "https://randomuser.me/api/portraits/men/35.jpg"
    },
    {
        id : 2,
        name: "Aman",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/34.jpg"
    },
    {
        id : 3,
        name: "Rahul",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/40.jpg"
    },
    {
        id : 4,
        name: "Amar",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/22.jpg"
    },
    {
        id : 5,
        name: "Pavan",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/32.jpg"
    },
    {
        id : 6,
        name: "Arjun",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/40.jpg"
    },
    {
        id : 1,
        name: "John",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/42.jpg"
    },
    {
        id : 2,
        name: "Aman",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/55.jpg"
    },
    {
        id : 3,
        name: "Rahul",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/54.jpg"
    },
    {
        id : 4,
        name: "Amar",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/41.jpg"
    },
    {
        id : 5,
        name: "Pavan",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/42.jpg"
    },
    {
        id : 6,
        name: "Arjun",
        active: false,
        icon: "https://randomuser.me/api/portraits/men/39.jpg"
    }
]

export default CandidatesSliderdata