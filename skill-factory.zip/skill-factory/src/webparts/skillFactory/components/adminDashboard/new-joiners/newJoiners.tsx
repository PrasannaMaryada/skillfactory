import * as React from "react";
import Table from "react-bootstrap/Table";
// import CandidateData from './CandidateList';
const newJoinersData = [
  {
    "EmpID": "33323",
    "name": "Aman",
    "AssignSF":true
  },
  {
    "EmpID": "23233",
    "name": "Soubhagya",
    "AssignSF":false
  },
  {
    "EmpID": "45233",
    "name": "Heetika",
    "AssignSF":true
  },
  {
    "EmpID": "33323",
    "name": "Aman",
    "AssignSF":true
  },
  {
    "EmpID": "23233",
    "name": "Soubhagya",
    "AssignSF":false
  },
  {
    "EmpID": "45233",
    "name": "Heetika",
    "AssignSF":true
  }
]

class NewJoiners extends React.Component {
  render() {
    return (
      <div>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Emp ID</th>
              <th>Name</th>
              <th>Assiign SF</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {newJoinersData.map((candidate) => {
                return (
                  <tr>
                    <td>{candidate.EmpID}</td>
                    <td>{candidate.name}</td>
                    <td>{candidate.AssignSF}</td>
                    <td><button className="btn btn-sm btn-primary">Action</button></td>
                  </tr>
                );
              })}
          </tbody>
        </Table>
      </div>
    );
  }
}

export default NewJoiners;
