const CandidateData = [
  {
    "id": 1,
    "name": "Aman",
    "icon": "images/dp.png",
    "skills":"JavaScript",
    "CC":1,
    "mentor_id":1
  },
  {
    "id": 2,
    "name": "Arun",
    "icon": "images/dp.png",
    "skills":"JavaScript,Java",
    "CC":2,
    "mentor_id":1
  },
  {
    "id": 3,
    "name": "Bibek",
    "icon": "images/dp.png",
    "skills":"JavaScript,Spfx",
    "CC":2,
    "mentor_id":2
  },
  {
    "id": 4,
    "name": "Ramesh",
    "icon": "images/dp.png",
    "skills":"JavaScript, Angular",
    "CC":2,
    "mentor_id":2
  },
  {
    "id": 5,
    "name": "Arbin",
    "icon": "images/dp.png",
    "skills":"JavaScript, React",
    "CC":2,
    "mentor_id":3
  },
  {
    "id": 6,
    "name": "Randhir",
    "icon": "images/dp.png",
    "skills":"JavaScript,CSS",
    "CC":2,
    "mentor_id":4
  }
]
