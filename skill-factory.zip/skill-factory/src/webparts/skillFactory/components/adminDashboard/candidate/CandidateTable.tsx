import * as React from "react";
import Table from "react-bootstrap/Table";
// import CandidateData from './CandidateList';
const CandidateData = [
  {
    "id": 1,
    "name": "Aman",
    "icon": "images/dp.png",
    "skills":"JavaScript",
    "CC":"course 1, course 1",
    "mentor_id":1
  },
  {
    "id": 2,
    "name": "Arun",
    "icon": "images/dp.png",
    "skills":"JavaScript,Java",
    "CC":"course 1, course 1",
    "mentor_id":1
  },
  {
    "id": 3,
    "name": "Bibek",
    "icon": "images/dp.png",
    "skills":"JavaScript,Spfx",
    "CC":"course 1, course 1",
    "mentor_id":2
  },
  {
    "id": 4,
    "name": "Ramesh",
    "icon": "images/dp.png",
    "skills":"JavaScript, Angular",
    "CC":"course 1, course 1",
    "mentor_id":2
  },
  {
    "id": 5,
    "name": "Arbin",
    "icon": "images/dp.png",
    "skills":"JavaScript, React",
    "CC":"course 1, course 1",
    "mentor_id":3
  },
  {
    "id": 6,
    "name": "Randhir",
    "icon": "images/dp.png",
    "skills":"JavaScript,CSS",
    "CC":"course 1, course 1",
    "mentor_id":4
  }
]

class CandidateTable extends React.Component {
  render() {
    return (
      <div>
       <h5>John's Team (6 Candidates)</h5>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Emp ID</th>
              <th>Name</th>
              <th>Skills</th>
              <th>Completed Courses</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {CandidateData.map((candidate) => {
                return (
                  <tr>
                    <td>{candidate.id}</td>
                    <td>{candidate.name}</td>
                    <td>{candidate.skills}</td>
                    <td>{candidate.CC}</td>
                    <td><button className="btn btn-sm btn-primary">Details</button> </td>
                  </tr>
                );
              })}
          </tbody>
        </Table>
      </div>
    );
  }
}

export default CandidateTable;
