import * as React from "react";
import Modal from 'react-bootstrap/Modal'
import Slider from 'react-slick'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'
// import MentorSliderdata from './MentorSliderdata'
const MentorSliderdata = [
  {
      id : 1,
      active: true,
      name: "John",
      icon: "https://randomuser.me/api/portraits/men/35.jpg"
  },
  {
      id : 2,
      name: "Aman",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/34.jpg"
  },
  {
      id : 3,
      name: "Rahul",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/40.jpg"
  },
  {
      id : 4,
      name: "Amar",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/22.jpg"
  },
  {
      id : 5,
      name: "Pavan",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/32.jpg"
  },
  {
      id : 6,
      name: "Arjun",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/40.jpg"
  },
  {
      id : 1,
      name: "John",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/42.jpg"
  },
  {
      id : 2,
      name: "Aman",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/55.jpg"
  },
  {
      id : 3,
      name: "Rahul",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/54.jpg"
  },
  {
      id : 4,
      name: "Amar",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/41.jpg"
  },
  {
      id : 5,
      name: "Pavan",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/42.jpg"
  },
  {
      id : 6,
      name: "Arjun",
      active: false,
      icon: "https://randomuser.me/api/portraits/men/39.jpg"
  }
]
class MentorListSlider extends React.Component {
  render() {
    const settings = {
      arrows: true,
      infinite: false,
      slidesToShow: 7,
      slidesToScroll: 7,
      speed: 500,
      className: 'slides',
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 4,
            initialSlide: 4,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
          },
        },
      ],
    }
    return (
      <div>
        {/* <Modal
          size="lg"
          show="true"
          aria-labelledby="example-modal-sizes-title-lg"
        >
          <Modal.Header>
            <Modal.Title>Mentor/Reviewer</Modal.Title>
          </Modal.Header>

          <Modal.Body> */}
            <Slider {...settings}>
              {MentorSliderdata.map(mentor => {
                return (
                  <div className={"slider_cont " + (mentor.active ? 'active' : '')} key={mentor.id}>
                    <div>
                      <img width="100%" src={mentor.icon} alt="dp" />
                    </div>
                    <div>{mentor.name}</div>
                  </div>
                )
              })}
            </Slider>
          {/* </Modal.Body>
        </Modal> */}
      </div>
    )
  }
}

export default MentorListSlider
