import * as React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import LeftPanel from "../shared/leftpanel/leftpanel";
import MentorListSlider from "./mentor/MentorList";
import CandidateTable from "./candidate/CandidateTable";
import NewJoiners from "./new-joiners/newJoiners";
import BatchChart from "./chats/batchChat";

class AdminDashboard extends React.Component {
  render() {
    return (
      <Container fluid={true}>
        <Row>
          <Col sm={3} bsPrefix="leftPanel col">
            <LeftPanel />
          </Col>
          <Col sm={9}>
            <div className="rightContainer">
              <h3>Good Morning  Nihar !</h3>
              <Row>
                <Col sm={8}>
                <BatchChart />
                </Col>
                <Col sm={4}>
                  <h5>New Joiners</h5>
                  <NewJoiners />
                </Col>
              </Row>
              <Row>
                <div className="mentCont col-sm-12">
                  <h5>Reviewers / Mentors</h5>
                  <MentorListSlider />
                  <CandidateTable />
                  {/* <Reviewer /> */}
                </div>
              </Row>
            </div>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default AdminDashboard;
