/* tslint:disable */
require("./SkillFactory.module.css");
const styles = {
  skillFactory: 'skillFactory_be04364f',
  teams: 'teams_be04364f',
  welcome: 'welcome_be04364f',
  welcomeImage: 'welcomeImage_be04364f',
  links: 'links_be04364f'
};

export default styles;
/* tslint:enable */