export interface manageCandiProps {
  leftPanelData:string
}
