import * as React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";


class Welcome extends React.Component {
  render() {
    return (
      <Container fluid={true}>
        <Row>
          <Col sm={12}>
            <div className="headWel">
              <div className="container py-2 h-100">
                <div className="row d-flex justify-content-center align-items-center h-100">
                  <div>
                    <div className="card">
                      <div className="card-body p-4">
                        <div className="d-flex text-black">
                          <div className="flex-shrink-0">
                            <img
                              src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-profiles/avatar-1.webp"
                              alt="Generic placeholder image"
                              className="img-fluid prof"
                            />
                          </div>
                          <div className="flex-grow-1 ms-3" style={{ textAlign: "left" }}>
                            <h3 className="mb-4">Hi Nihar !</h3>
                            <h5 className="mb-1">
                              Welcome to Skill Factory Training
                            </h5>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="container py-4">
              <h5>About Skill Factory</h5>
              <p>A structured, flexible & guided learning program. We have designed a flexible program for you. A structured, flexible & guided learning program. We have designed a flexible program for you. A structured, flexible & guided learning program. We have designed a flexible program for you. A structured, flexible & guided learning program. We have designed a flexible program for you. A structured, flexible & guided learning program. We have designed a flexible program for you. A structured, flexible & guided learning program. We have designed a flexible program for you. A structured, flexible & guided learning program. We have designed a flexible program for you... </p>
            </div>
         
            <ul className="steps-panel">
              <li className="step1">
                <a>
                  <div>
                    <strong>Beginner</strong>
                    <p>The purpose of lorem ipsum is to create a natural looking block of text sentence...</p>
                  </div>
                </a>
              </li>
              <li className="step2">
                <a>
                  <div>
                    <strong>Intermediate</strong>
                    <p>The passage experienced a surge in popularity during the 1960s...</p>
                  </div>
                </a>
              </li>
              <li className="step3">
                <a>
                  <div>
                    <strong>Advanced</strong>
                    <p>Until recently, the prevailing view assumed lorem ipsum was born as a nonsense text...</p>
                  </div>
                </a>
              </li>
              <li className="step4">
                <a>
                  <div>
                    <strong>Bootcamp</strong>
                    <p>Richard McClintock, a Latin scholar from Hampden-Sydney College...</p>
                  </div>
                </a>
              </li>
            </ul>
            <div className="row d-flex justify-content-center align-items-center py-5">
               <Link className="w-25 btn btn-primary" to="/admin">Continue to Profile</Link>
              </div>
          </Col>
        </Row>
       
      </Container>
    );
  }
}

export default Welcome;
