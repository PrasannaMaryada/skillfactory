import * as React from 'react';
import './candidateProfilePage.css';
import { Button, Card } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
// import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
// import PhoneOutlinedIcon from '@mui/icons-material/PhoneOutlined';
// import Person2OutlinedIcon from '@mui/icons-material/Person2Outlined';
// import PinDropOutlinedIcon from '@mui/icons-material/PinDropOutlined';
// import ContactMailOutlinedIcon from '@mui/icons-material/ContactMailOutlined';
// import AccountTreeOutlinedIcon from '@mui/icons-material/AccountTreeOutlined';
// import AssistantOutlinedIcon from '@mui/icons-material/AssistantOutlined';
// import Vector from '../assets/Vector.png'
// import sheildIcon from '../assets/sheildIcon.png'
// import phone from '../assets/phone.png'
// import email from '../assets/email.png'
// import person from '../assets/person.png'
// import empId from '../assets/empId.png'
// import gps from '../assets/gps.png'


// import organisation from '../assets/organisation.png'


import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
// import CourseCard from '../../Components/CourseCard/courseCard';
import Nav from 'react-bootstrap/Nav';
import CourseStatus from './CourseStatus/courseStatus';

class CandidateProfilePage extends React.Component<any,any> {
    render() {
        return (
            <main style={{ overflow: 'scroll', width: '100%' }}>
                <Container fluid>
                    <Row>
                        <Col className='' sm={12}>

                            <div className='p-2' style={{ background: '#F6F6F6', }}>


                                <Row>
                                    <Col sm={2} style={{}} >
                                        <div style={{ display: 'flex', justifyContent: 'center', }}>
                                            <div style={{ height: 75, width: 75, borderRadius: 35.25, background: 'grey' }}>

                                            </div>
                                        </div>

                                        <Row className='mt-1' >
                                            {/* <Stack direction="horizontal" gap={2} style={{ display: 'flex', justifyContent: 'center', }}>
                                            <p className="  mb-0" style={{ fontSize: '10px' }}><AssistantOutlinedIcon sx={{ fontSize: 12 }} /></p>
                                            <p className="  mb-0 companyDetail">15</p>
                                            <img className="  mb-0 mt-1" src={Vector} style={{ width: 12 }}></img>
                                            <p className="  mb-0 companyDetail" >15</p>
                                        </Stack> */}

                                            <Row style={{ flexWrap: 'wrap' }}>
                                                <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap' }}>
                                                    <img alt='sheildIcon' className=" mb-0 mt-1" src="https://tataelxsi.sharepoint.com/:i:/r/sites/TATA_ELXSI_SKILL_FACTORY/assets/sheildIcon.png" style={{ width: 12, marginLeft: 15, marginRight: 4 }} />
                                                    <p className="  mb-0 companyDetail ">15</p>


                                                    <img alt="vector" className="  mb-0 mt-1" src="https://tataelxsi.sharepoint.com/:i:/r/sites/TATA_ELXSI_SKILL_FACTORY/assets/Vector.png" style={{ width: 12, marginLeft: 10, marginRight: 4 }}></img>
                                                    <p className="  mb-0 companyDetail" style={{ marginLeft: 2 }} >15</p>
                                                </div>

                                            </Row>
                                        </Row>



                                    </Col >
                                    <Col sm={5} style={{}}>
                                        <Row>
                                            <Col sm={9}>
                                                <div  >
                                                    <p className="fs-6 fw-bolder mb-0" >Mohankumar!</p>
                                                </div>


                                                {/* <Stack direction="horizontal" gap={2}>
                                                    <p className="  mb-0" style={{ fontSize: '12px' }}><EmailOutlinedIcon sx={{ fontSize: 12 }} /></p>
                                                    <a className="  mb-0" style={{ fontSize: '10px' }}>vishnu@tataelxsi.co.in</a>
                                                </Stack> */}
                                                <div>
                                                    <span>
                                                        <p className=" " style={{ fontSize: '12px', display: 'inline' }}><img className="  mb-0 " src="https://tataelxsi.sharepoint.com/:i:/r/sites/TATA_ELXSI_SKILL_FACTORY/assets/email.png" style={{ width: 12 }}></img></p>
                                                    </span>
                                                    <span>
                                                        <a className=" " style={{ fontSize: '12px', marginLeft: 7 }}>vishnu@tataelxsi.co.in</a>
                                                    </span>
                                                </div>


                                                <div className=" ">
                                                    {/* <Stack direction="horizontal" gap={2}>
                                                    <p className="  mb-0 companyDetail" ><PhoneOutlinedIcon sx={{ fontSize: 12 }} /></p>
                                                    <p className="  mb-0 companyDetail" >(+91) 9840200287</p>
                                                </Stack> */}
                                                    <span>
                                                        <p className=" " style={{ fontSize: '12px', display: 'inline' }}><img alt='phone' className="  mb-0 " src="https://tataelxsi.sharepoint.com/:i:/r/sites/TATA_ELXSI_SKILL_FACTORY/assets/phone.png" style={{ width: 12 }}></img></p>
                                                    </span>
                                                    <span>
                                                        <p className="  mb-0 companyDetail" style={{ marginLeft: 7 }} >(+91) 9840200287</p>
                                                    </span>
                                                </div>


                                                <div className=" ">
                                                    {/* <Stack direction="horizontal" gap={2}>
                                                    <p className="  mb-0" ><Person2OutlinedIcon sx={{ fontSize: 12 }} /></p>
                                                    <p className="  mb-0 companyDetail" >Senior Engineer (Grade: C)</p>
                                                </Stack> */}

                                                    <span>
                                                        <p className=" " style={{ fontSize: '12px', display: 'inline' }}><img alt="eng" className="  mb-0 " src="https://tataelxsi.sharepoint.com/:i:/r/sites/TATA_ELXSI_SKILL_FACTORY/assets/person.png" style={{ width: 10 }}></img></p>
                                                    </span>
                                                    <span>
                                                        <p className="  mb-0 companyDetail" style={{ marginLeft: 7 }}>Senior Engineer (Grade: C)</p>
                                                    </span>



                                                </div>

                                            </Col>
                                            <Col sm={3} style={{ borderWidth: "10px", borderColor: 'black' }}>
                                                <div style={{ borderWidth: "10px", borderColor: 'black', height: '100%', width: '1px', background: '#818181' }}>

                                                </div>
                                            </Col>

                                        </Row>
                                    </Col>


                                    <Col sm={5} style={{}}>
                                        <div  >
                                            <p className="fs-6 fw-bolder mb-0" style={{ visibility: 'hidden' }}>Vishnu Mohan!</p>
                                        </div>

                                        <div>
                                            {/* <Stack direction="horizontal" gap={2}>
                                            <p className="  mb-0" ><ContactMailOutlinedIcon sx={{ fontSize: 12 }} /></p>
                                            <p className="  mb-0 companyDetail" >Emp ID: 31857</p>
                                        </Stack> */}
                                            <span>
                                                <span>
                                                    <p className=" " style={{ fontSize: '12px', display: 'inline' }}><img alt='empid' className="  mb-0 " src="https://tataelxsi.sharepoint.com/:i:/r/sites/TATA_ELXSI_SKILL_FACTORY/assets/empId.png" style={{ width: 12 }}></img></p>
                                                </span>
                                            </span>

                                            <span>
                                                <p className="  mb-0 companyDetail" style={{ marginLeft: 7 }}>Emp ID: 31857</p>

                                            </span>

                                        </div>
                                        <div className=" ">
                                            {/* <Stack direction="horizontal" gap={2}>
                                            <p className="  mb-0" ><AccountTreeOutlinedIcon sx={{ fontSize: 12 }} /></p>
                                            <p className="  mb-0 companyDetail" >Reports To: Ganesh V</p>
                                        </Stack> */}

                                            <span>
                                                <p className=" " style={{ fontSize: '12px', display: 'inline' }}><img alt='organization' className="  mb-0 " src="https://tataelxsi.sharepoint.com/:i:/r/sites/TATA_ELXSI_SKILL_FACTORY/assets/organisation.png" style={{ width: 12 }}></img></p>

                                            </span>
                                            <span>
                                                <p className="  mb-0 companyDetail" style={{ marginLeft: 7 }}>Reports To: Ganesh V</p>
                                            </span>
                                        </div>
                                        <div className=" ">
                                            {/* <Stack direction="horizontal" gap={2}>
                                            <p className="  mb-0" ><PinDropOutlinedIcon sx={{ fontSize: 12 }} /></p>
                                            <p className="  mb-0 companyDetail" >City/Location: TEL-Trivandrum ( TVM-Kinfra SEZ )</p>
                                        </Stack> */}
                                            <span>
                                                <p className=" " style={{ fontSize: '12px', display: 'inline' }}><img alt="gps" className="  mb-0 " src="https://tataelxsi.sharepoint.com/:i:/r/sites/TATA_ELXSI_SKILL_FACTORY/assets/gps.png" style={{ width: 12 }}></img></p>
                                            </span>
                                            <span>
                                                <p className="  mb-0 companyDetail" style={{ marginLeft: 7 }}>City/Location: TEL-Trivandrum ( TVM-Kinfra SEZ )</p>
                                            </span>
                                        </div>
                                    </Col>

                                </Row>

                                <Row className='mt-2 p-2'>


                                    {/* <Stack gap={1} style={{ display: 'flex', justifyContent: 'center', }}>
                                        <p className="  mb-0 companyDetail" style={{}}>Organization</p>
                                        <p className="  mb-0 companyDetail">Tata Elxsi</p>

                                    </Stack>
                                    <Stack gap={1} style={{ display: 'flex', justifyContent: 'center', }}>
                                        <p className="  mb-0 companyDetail" >IOU</p>
                                        <p className="  mb-0 companyDetail">EPD Broadcast</p>

                                    </Stack>
                                    <Stack gap={1} style={{ display: 'flex', justifyContent: 'center', }}>
                                        <p className="  mb-0 companyDetail" >Sub IOU</p>
                                        <p className="  mb-0 companyDetail" >BBU-OTT</p>

                                    </Stack>
                                    <Stack gap={1} style={{ display: 'flex', justifyContent: 'center', }}>
                                        <p className="  mb-0 companyDetail" >Domain</p>
                                        <p className="  mb-0 companyDetail" >N/A</p>

                                    </Stack>
                                    <Stack gap={1} style={{ display: 'flex', justifyContent: 'center', }}>
                                        <p className="  mb-0 companyDetail" >Role</p>
                                        <p className="  mb-0 companyDetail" >N/A</p>

                                    </Stack>
                                    <Stack gap={1} style={{ display: 'flex', justifyContent: 'center', }}>
                                        <p className="  mb-0 companyDetail" >Team</p>
                                        <p className="  mb-0 companyDetail" >Broadcast</p>

                                    </Stack> */}

                                    <Col className='mt-1' xs={4} sm={2}>
                                        <div>
                                            <p className="  mb-0 companyDetail" style={{}}>Organization</p>
                                        </div>
                                        <div>
                                            <p className="  mb-0 companyDetail">Tata Elxsi</p>
                                        </div>
                                    </Col>

                                    <Col className='mt-1' xs={4} sm={2}>

                                        <div>
                                            <p className="  mb-0 companyDetail" >IOU</p>
                                        </div>
                                        <div>
                                            <p className="  mb-0 companyDetail">EPD Broadcast</p>
                                        </div>
                                    </Col>


                                    <Col className='mt-1' xs={4} sm={2}>

                                        <div>
                                            <p className="  mb-0 companyDetail" >Sub IOU</p>
                                        </div>
                                        <div>
                                            <p className="  mb-0 companyDetail" >BBU-OTT</p>
                                        </div>
                                    </Col>

                                    <Col className='mt-1' xs={4} sm={2}>

                                        <div>
                                            <p className="  mb-0 companyDetail" >Domain</p>
                                        </div>
                                        <div>
                                            <p className="  mb-0 companyDetail" >N/A</p>
                                        </div>
                                    </Col>

                                    <Col className='mt-1' xs={4} sm={2}>

                                        <div>
                                            <p className="  mb-0 companyDetail" >Role</p>
                                        </div>
                                        <div>
                                            <p className="  mb-0 companyDetail" >N/A</p>
                                        </div>
                                    </Col>

                                    <Col className='mt-1' xs={4} sm={2}>

                                        <div>
                                            <p className="  mb-0 companyDetail" >Team</p>
                                        </div>
                                        <div>
                                            <p className="  mb-0 companyDetail" >Broadcast</p>
                                        </div>
                                    </Col>








                                </Row>

                            </div>
                            <CourseStatus />

                            <Tabs
                                id="controlled-tab-example"


                                className="mb-3 mt-2"
                            >
                                    {/* <CourseStatus /> */}

                                {/* <Tab eventKey="home" title="Profile">
                                    <CourseStatus />
                                </Tab>
                                <Tab eventKey="profile" title="Courses">
                                    <CourseStatus />
                                </Tab> */}

                            </Tabs>


                        </Col>


                    </Row>
                </Container>
            </main>
        );
    }
}

export default CandidateProfilePage;
