import * as React from "react";
import "./courseStatus.css";
import Row from "react-bootstrap/Row";
import { ToggleButton, Button, ToggleButtonGroup } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import CourseCard from "../../shared/coursecard/courseCard";
const courseData = [
  {
    course_title: "Introduction to Javascript wdwffwffqfgqgfafewgwgewgwgewggg",
    course_duration: "10 Hours",
    percentage: 50,
    sources: "youtube",
  },
  {
    course_title: "Introduction to React",
    course_duration: "12 Hours",
    percentage: 80,
    sources: "youtube",
  },
  {
    course_title: "Introduction to Angular",
    course_duration: "8 Hours",
    percentage: 70,
    sources: "youtube",
  },
  {
    course_title: "Introduction to Babel",
    course_duration: "2 Hours",
    percentage: 90,
    sources: "youtube",
  },
  {
    course_title: "CSS Advance",
    course_duration: "20 Hours",
    percentage: 10,
    sources: "youtube",
  },
  {
    course_title: "React L1",
    course_duration: "20 Hours",
    percentage: 10,
    sources: "youtube",
  },
  {
    course_title: "React L2",
    course_duration: "22 Hours",
    percentage: 25,
    sources: "youtube",
  },
  {
    course_title: "OTT Introduction",
    course_duration: "25 Hours",
    percentage: 45,
    sources: "youtube",
  },
  {
    course_title: "Vedio Delivery",
    course_duration: "12 Hours",
    percentage: 40,
    sources: "youtube",
  },
  {
    course_title: "Common Coding Implementaion",
    course_duration: "12 Hours",
    percentage: 40,
    sources: "youtube",
  },
];

class CourseStatus extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      inProgressBtn: true,
      completedBtn: false,
    };
  }
  OnclickInprogressBtn = () => {
    this.setState({ inProgressBtn: true, completedBtn: false });
  };
  OnclickCompletedBtn = () => {
    this.setState({ inProgressBtn: false, completedBtn: true });
  };
  render() {
    return (
      <Container>
        <div>
          <div style={{ display: "flex", justifyContent: "center" }}>
            <ToggleButtonGroup type="checkbox" size="sm">
              <Button
                id="tbg-btn-1"
                value={1}
                active
                onClick={this.OnclickInprogressBtn}
              >
                Inprogress
              </Button>
              <Button
                id="tbg-btn-2"
                value={2}
                variant="secondary"
                active={false}
                onClick={this.OnclickCompletedBtn}
              >
                Completed
              </Button>
            </ToggleButtonGroup>
          </div>
          <Row>
            {courseData.map((item) => (
              <CourseCard item={item} />
            ))}
          </Row>
          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              paddingBottom: 20,
            }}
          >
            {/* <Pagination count={2} showFirstButton showLastButton size="small" /> */}
          </div>
        </div>
      </Container>
    );
  }
}

export default CourseStatus;
