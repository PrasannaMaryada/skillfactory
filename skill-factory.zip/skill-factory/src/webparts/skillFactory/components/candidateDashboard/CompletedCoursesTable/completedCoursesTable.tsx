import * as React from 'react';
import './completedCoursesTable.css';

import Table from 'react-bootstrap/Table';
import { Button} from 'react-bootstrap';


class CompletedCoursesTable extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }
    render() {


        return (
            <Table striped hover >
                <thead >
                    <tr>
                        <th>Course Name</th>
                        <th>Total Hours</th>
                    </tr>
                </thead>
                <tbody>
                    {this.props.data.map((item: any) =>
                    (
                        <tr>

                            <td>{item.course_name}</td>
                            <td>{item.duration}</td>
                            <td><Button className='btn btn-default btn-block' variant="primary" size="sm">Details</Button>{' '}
                            </td>
                        </tr>
                    ))

                    }

                </tbody>
            </Table>
        )
    }
}

export default CompletedCoursesTable