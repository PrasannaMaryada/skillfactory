import * as React from 'react';
import './assignmentCard.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col'
import { Button } from 'react-bootstrap';


class AssignmentCard extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
    }
    render() {
        console.log(this.props.item)
        return (
            <Col className='' sm={3} xs={5} md={3} lg={3} xl={2} xxs={12} style={{ margin: 10, background: '#a9e7fb', borderRadius: 10 }}>
                <div >
                    <Row className=''>
                        <Col className='d-flex justify-content-end ' style={{ paddingLeft: 15, paddingRight: 5 }} >
                            {/* <Stack direction="horizontal" gap={2} className='mt-3 tabAlignment'> */}
                            <div className="hstack gap-2 mt-3 tabAlignment">
                                {
                                    this.props.item.skills.map((e: any) =>
                                    (

                                        <span style={{ background: '#1386ab', display: 'inline-block', width: 60, fontSize: 10, color: 'white' }}>{e}</span>



                                    ))
                                }
                                {/* <span style={{ background: '#1386ab', display: 'inline-block', width: 60, fontSize: 10, color: 'white' }}>css</span>

                                <span style={{ background: '#1386ab', display: 'inline-block', width: 60, fontSize: 10, color: 'white' }}>js</span> */}
                            </div>
                            {/* </Stack> */}
                        </Col>
                    </Row>



                    <div style={{ display: 'flex', justifyContent: 'start' }}>
                        <p className="fs-4 fw-bolder">{this.props.item.assessment_title}</p>
                    </div>

                    <Row>
                        <div style={{ display: 'flex', justifyContent: 'start' }}>
                            <p className=" fw-bolder desc  " style={{ fontSize: 16, color: 'black', opacity: 0.6, textAlign: 'left' }}> {this.props.item.assesment_desc}</p>
                        </div>
                    </Row>


                    <Row>
                        <Col className='d-flex justify-content-center '>

                            <Button className='btn btn-default btn-block' style={{ width: '100%', opacity: 0.5, marginLeft: 5, marginRight: 5, }} variant="primary" size="sm">View</Button>{' '}
                        </Col>
                    </Row>

                    <Row>
                        <Col className='d-flex justify-content-end'>

                            <p className=" fw-bolder mt-1 mb-0 " style={{ fontSize: 14, color: 'black', opacity: 0.6 }}>{this.props.item.duration}</p>
                        </Col>
                    </Row>
                </div>
            </Col>
        )
    }
}

export default AssignmentCard