import * as React from "react";
import "./statusUpdateBox.css";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { Button, Card } from "react-bootstrap";

class StatusUpdateBox extends React.Component {
  render() {
    return (
      <div
        className="p-2"
        style={{ backgroundColor: "#DCDCDC", borderRadius: 10 }}
      >
        <Col className="d-flex justify-content-end p-2">
          <p className=" fw-bolder text-primary" style={{ fontSize: 12 }}>
            Previous Status History
          </p>
        </Col>
        <Card>
          <Card.Body>
            <textarea
              id="w3review"
              name="w3review"
              rows={4}
              cols={50}
              style={{ border: "0px", width: "100%" }}
            >
              Finished webpack:4 beyond basics,Finished webpack:4 beyond
              basics,Finished webpack:4 beyond basics
            </textarea>
          </Card.Body>
        </Card>
        <div className="d-flex justify-content-end p-3 ">
          <Button variant="primary" className="d-flex align-self-end">
            Update
          </Button>
        </div>
      </div>
    );
  }
}

export default StatusUpdateBox;
