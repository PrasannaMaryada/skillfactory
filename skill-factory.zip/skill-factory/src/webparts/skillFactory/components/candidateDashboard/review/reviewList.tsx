import * as React from 'react';
import './reviewList.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col'
import { Button, ListGroup } from 'react-bootstrap';


class ReviewList extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
    }
    render() {


        return (
            <ListGroup style={{ backgroundColor: '#DCDCDC', borderRadius: 10, padding: '15px 15px 15px 10px' }}>
                {this.props.data.map((data: any, idx: any) => (
                    <ListGroup.Item variant={idx % 2 == 0 ? 'light' : "secondary"}>
                        <Row >
                            <Col className='d-flex justify-content-start mt-2 ' sm={8} xs={8}>
                                <p className=" fw-bolder desc_1" style={{ fontSize: 14 }}>{data.review}</p>
                            </Col>

                            <Col className='d-flex justify-content-end ' sm={4} xs={4}>
                                <div style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>
                                    <Button variant="primary" size="sm">
                                        Action
                                    </Button>
                                </div>

                            </Col>
                        </Row>
                    </ListGroup.Item>
                ))}
            </ListGroup>
        )
    }
}

export default ReviewList