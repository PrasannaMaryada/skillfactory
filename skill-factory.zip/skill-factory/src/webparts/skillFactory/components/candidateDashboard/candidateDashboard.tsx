import * as React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import LeftPanel from "../shared/leftpanel/leftpanel";
import CourseCard from "../shared/coursecard/courseCard";
import ReviewList from "./review/reviewList";
import StatusUpdateBox from "./StatusUpdateBox/statusUpdateBox";
import AssignmentCard from "./AssignmentCard/assignmentCard";
import CompletedCoursesTable from "./CompletedCoursesTable/completedCoursesTable";
import { Button } from "react-bootstrap";

// import Stack from 'react-bootstrap/Stack';

const courseListData = [
  {
    course_title: "Introduction to Javascript wdwffwffqfgqgfafewgwgewgwgewggg",
    course_duration: "10 Hours",
    percentage: 50,
    sources: "youtube",
  },
  {
    course_title: "Introduction to React",
    course_duration: "12 Hours",
    percentage: 80,
    sources: "youtube",
  },
  {
    course_title: "Introduction to Angular",
    course_duration: "8 Hours",
    percentage: 70,
    sources: "youtube",
  },
  {
    course_title: "Introduction to Babel",
    course_duration: "2 Hours",
    percentage: 90,
    sources: "youtube",
  },
  {
    course_title: "CSS Advance",
    course_duration: "20 Hours",
    percentage: 10,
    sources: "youtube",
  },
  {
    course_title: "React L1",
    course_duration: "20 Hours",
    percentage: 10,
    sources: "youtube",
  },
  {
    course_title: "React L2",
    course_duration: "22 Hours",
    percentage: 25,
    sources: "youtube",
  },
  {
    course_title: "OTT Introduction",
    course_duration: "25 Hours",
    percentage: 45,
    sources: "youtube",
  },
  {
    course_title: "Vedio Delivery",
    course_duration: "12 Hours",
    percentage: 40,
    sources: "youtube",
  },
  {
    course_title: "Common Coding Implementaion",
    course_duration: "12 Hours",
    percentage: 40,
    sources: "youtube",
  },
];
const ReviewListData = [
  {
    review: "Lorem Ipsum Set Dolor Lorem Ipsum",
  },
  {
    review: "Lorem Ipsum Set Dolor Lorem Ipsum",
  },
  {
    review: "Lorem Ipsum Set Dolor Lorem Ipsum",
  },
  {
    review: "Lorem Ipsum Set Dolor Lorem Ipsum",
  },
];
const AssessmentListData = [
  {
    skills: ["html", "css", "js"],
    assessment_title: "99 Design",
    assesment_desc: "Create a website similar to 99design.com.",
    duration: "20 Hours",
  },
  {
    skills: ["react", "js"],
    assessment_title: "Sky Store",
    assesment_desc: "Create a website similar to skystore.com.",
    duration: "22 Hours",
  },
  {
    skills: ["html", "css", "js"],
    assessment_title: "99 Design",
    assesment_desc: "Create a website similar to 99design.com.",
    duration: "20 Hours",
  },
  {
    skills: ["html", "react", "js"],
    assessment_title: "Sky Store",
    assesment_desc: "Create a website similar to skystore.com.",
    duration: "22 Hours",
  },
  {
    skills: ["react", "js"],
    assessment_title: "Sony Liv",
    assesment_desc: "Create a website similar to sonyLiv.com.",
    duration: "22 Hours",
  },
];
const completedCoursesList = [
  {
    course_name: "OTT_FE",
    duration: "16 hrs",
  },
  {
    course_name: "JavaScript",
    duration: "12 hrs",
  },
  {
    course_name: "React",
    duration: "22 hrs",
  },
];

class CandidateDashboard extends React.Component {
  render() {
    return (
      <div className="App">
        <Container fluid={true} className="p-4">
          <Row>
            <Col sm={3} bsPrefix="leftPanel col">
              <LeftPanel />
            </Col>
            <Col sm={9}>
              <div className="rightContainer">
                <Row className="justify-content-md-center">
                  <Col sm={12}  className="d-flex justify-content-start  ">
                    

                    <Row>
                      <div className="d-flex ">
                        <div
                          className="profile"
                          style={{
                            height: 40,
                            width: 40,
                            borderRadius: "50%",
                            backgroundColor: "#DCDCDC",
                          }}
                        >
                          {" "}
                        </div>

                        <div style={{ marginLeft: 6 }}>
                          <p className="fs-5 fw-bolder mt-1">
                            Good Morning Mohankumar!
                          </p>
                        </div>
                      </div>
                    </Row>
                  </Col>

                  <Col sm={4} xs={4} className="d-flex justify-content-end ">
                    <div>
                      {/* <NotificationsActiveOutlinedIcon /> */}
                    </div>
                  </Col>
                </Row>
                <Row>
                  <Col className="d-flex justify-content-end  text-primary fw-bolder">
                    {" "}
                    Show More...
                  </Col>
                </Row>
                <Row style={{}}>
                  {courseListData.slice(0, 5).map((item) => (
                    <CourseCard item={item} />
                  ))}
                </Row>

                <Row className="mt-4">
                  {/* ReviewList */}
                  <Col xs={12} sm={12} lg={6}>
                    <Row
                      className="p-2 "
                      style={{
                        display: "flex",
                        alignItems: "end",
                        marginRight: 10,
                      }}
                    >
                      <Col className="d-flex justify-content-start  ">
                        <p className="fs-4 fw-bolder">Reviews</p>
                      </Col>
                      <Col className="d-flex justify-content-end  ">
                        <p
                          className=" fw-bolder text-primary"
                          style={{ fontSize: 14 }}
                        >
                          View All
                        </p>
                      </Col>
                    </Row>
                    <ReviewList data={ReviewListData} />
                  </Col>

                  {/* Status Update Section */}
                  <Col xs={12} sm={12} lg={6}>
                    <Row
                      className="p-2 d flex justify-content-start"
                      style={{ display: "flex", alignItems: "center" }}
                    >
                      <Col className="d-flex justify-content-start">
                        <p className="fs-4 fw-bolder">Today's Status Update</p>
                      </Col>
                    </Row>

                    <StatusUpdateBox />
                  </Col>
                </Row>
                <Row className="mt-4">
                  <Col className="d-flex justify-content-start  ">
                    <p className="fs-4 fw-bolder">Assignments</p>
                  </Col>
                  <Col className="d-flex justify-content-end  ">
                    <p className="text-primary  fw-bolder mt-1">Show More...</p>
                  </Col>
                </Row>
                <Row>
                  {AssessmentListData.map((data, idx) => (
                    <AssignmentCard item={data} />
                  ))}
                </Row>
                <Row className="mt-4">
                  <Col className="d-flex justify-content-start  ">
                    <p className="fs-4 fw-bolder">Completed Courses</p>
                  </Col>
                  <Col className="d-flex justify-content-end  text-primary">
                    <div>
                      <Button
                        className="btn btn-default btn-block"
                        variant="primary"
                        size="sm"
                      >
                        Actions
                      </Button>{" "}
                    </div>
                  </Col>
                </Row>

                <hr></hr>

                <CompletedCoursesTable data={completedCoursesList} />
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default CandidateDashboard;
