import * as React from "react";
import { Link } from "react-router-dom";
const menuList = []

class LeftPanel extends React.Component {
  render() {
    return (
      <ul className="list-group">
        <li className="list-group-item active">
        <Link to="/admin">Dashboard</Link>
        </li>
        <li className="list-group-item">Roles</li>
        <li className="list-group-item">
          <Link to="/manageCandidates">Candidates</Link>
        </li>
        <li className="list-group-item">Switch Roles</li>
      </ul>
    );
  }
}

export default LeftPanel;
