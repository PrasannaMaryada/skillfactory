import * as React from "react";
import "./courseCard.css";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import ProgressBar from "react-bootstrap/ProgressBar";
// import PlayCircleFilledOutlinedIcon from "@mui/icons-material/PlayCircleFilledOutlined";
// import YouTubeIcon from "@mui/icons-material/YouTube";

class CourseCard extends React.Component<any> {
  constructor(props: any) {
    super(props);
    this.state = {
      inProgressBtn: true,
      completedBtn: false,
    };
  }
  render() {
    return (
      <Col
        sm={2}
        xs={5}
        md={3}
        lg={3}
        xl={2}
        style={{ margin: 10, background: "#a9c0fb", borderRadius: 10 }}
      >
        <div style={{}}>
          <Row>
            <Col>
              <div className="d-flex justify-content-end mt-1">
                {/* <YouTubeIcon sx={{ color: "red" }} /> */}
              </div>
            </Col>
          </Row>
          <div>
            <p
              className="fs-5 fw-bolder alignment"
              style={{ textAlign: "left" }}
            >
              {this.props.item.course_title}
            </p>
          </div>
          <Row>
            <Col className="d-flex justify-content-end">
              <p className=" fw-bolder mt-2" style={{ fontSize: 10 }}>
                {this.props.item.course_duration}
              </p>
            </Col>
          </Row>

          <Row className="d-flex justify-content-center align-self-end">
            <Col sm={8} className="align-self-center">
              <ProgressBar now={this.props.item.percentage} />
            </Col>

            <Col sm={4}>
              <div className="d-flex justify-content-end">
                <p className="fs-6 fw-bolder mt-2">
                  {/* <PlayCircleFilledOutlinedIcon /> */}
                </p>
              </div>
            </Col>
          </Row>
        </div>
      </Col>
    );
  }
}

export default CourseCard;
