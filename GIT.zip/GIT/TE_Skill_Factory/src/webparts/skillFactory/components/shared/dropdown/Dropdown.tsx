 
import * as React from 'react';
import {Form} from 'react-bootstrap';
import { BsHandbag } from 'react-icons/bs';

interface DropDownProps 
{
    skills:string[],
}

interface DropDownState
{  
    value:string
}

export default class Dropdown extends React.Component<DropDownProps,DropDownState>
{
    constructor(props:DropDownProps)
    {
        super(props);
        this.state = {value: ""};
        this.handleDropDownChange = this.handleDropDownChange.bind(this);
    }

    handleDropDownChange(e: { target: { value: any; }; }) { 
        console.log(e.target.value);
        this.setState({ value: e.target.value });
      }

// eslint-disable-next-line @typescript-eslint/explicit-member-accessibility, @typescript-eslint/explicit-function-return-type
render(){
    return(
<Form.Control as="Select" aria-label='skill' name="skill" value={this.state.value} onChange={this.handleDropDownChange}> 
    {this.props.skills.map((skill, index) =>{
        // console.log(skill);
     // eslint-disable-next-line react/jsx-key
     return(<option value={skill}>{skill}</option>)
    })}
 </Form.Control>
    )
}

 
}