import * as React from "react";
// import FiX from 'react-icons/fi'
import { Link, NavLink } from "react-router-dom";
import { Button, Card } from "react-bootstrap";
const menuList = [
  { menuItem: "adminDashboard", name: "AdminDashboard" },
  { menuItem: "manageCandidate", name: "Manage Candidate" },
  { menuItem: "reviewerDashboard", name: "Reviewer Dashboard" },
  { menuItem: "candidateDashboard", name: "Candidate Dashboard" },
  { menuItem: "Profile", name: "Profile" },
];

class LeftPanel extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
  }
  render() {
    console.log("PROP", this.props);
    return (
      <ul className="list-group">
        {menuList.map((list) => (
          <li
            className={`list-group-item ${
              this.props.menuData === list.menuItem ? "active" : ''
            }`}
          >
            <Link to={`/${list.menuItem}`}>{list.name}</Link>
          </li>
        ))}
      </ul>
      //   <ul className="list-group">
      //     <li className="list-group-item active">
      //     <Link to="/admin">Dashboard</Link>
      //     </li>
      //     <li className="list-group-item">
      //       <Link to="/manageCandidates">Manage Candidates</Link>
      //     </li>
      //   </ul>
    );
  }
}

export default LeftPanel;
