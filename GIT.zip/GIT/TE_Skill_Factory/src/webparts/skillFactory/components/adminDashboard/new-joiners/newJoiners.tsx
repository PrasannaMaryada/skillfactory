import * as React from "react";
import Table from "react-bootstrap/Table";
import Modal from 'react-bootstrap/Modal';
import { XCircle } from "react-bootstrap-icons";
import axios from 'axios';
const newJoinersData = [
  {
    "EmpID": "33323",
    "name": "Aman",
    "AssignSF": true
  },
  {
    "EmpID": "23233",
    "name": "Soubhagya",
    "AssignSF": false
  },
  {
    "EmpID": "45233",
    "name": "Heetika",
    "AssignSF": true
  },
  {
    "EmpID": "33323",
    "name": "Aman",
    "AssignSF": true
  },
  {
    "EmpID": "23233",
    "name": "Soubhagya",
    "AssignSF": false
  },
  {
    "EmpID": "45233",
    "name": "Heetika",
    "AssignSF": true
  },
  {
    "EmpID": "33323",
    "name": "Aman",
    "AssignSF": true
  },
  {
    "EmpID": "23233",
    "name": "Soubhagya",
    "AssignSF": false
  },
  {
    "EmpID": "45233",
    "name": "Heetika",
    "AssignSF": true
  },
  {
    "EmpID": "33323",
    "name": "Aman",
    "AssignSF": true
  },
  {
    "EmpID": "23233",
    "name": "Soubhagya",
    "AssignSF": false
  },
  {
    "EmpID": "45233",
    "name": "Heetika",
    "AssignSF": true
  }
];




class NewJoiners extends React.Component<any, any> {
  constructor(props: any) {
    super(props);

    this.state = {
      show: false,
      data:""
    }

  }

  handleShow = () => {
    this.setState({
      ...this.state,
      show: true
    })
  }

  handleClose = () => {
    this.setState({
      ...this.state,
      show: false
    })
  }

  componentDidMount(): void {
  //   const url = "http://10.1.2.136:3001/api/user/listUsers?jahsvhj=1&paganiation=10";
  //   var config = {
  //     method:'GET',
  //     url:url
  //   }

  //   axios(config).then((response)=>{
    // console.log('====================================');
    // console.log(response);
    // console.log('====================================');
  //  this.setState({
  //   ...this.state,
  //   data:response.data
  //  })
  //   });

  // start
  const newjionersdata = [
    {
        "id": 5,
        "emp_id": "31769",
        "name": "vishnu",
        "trainings": null,
        "grade": "h",
        "emp_email": "vishnu@tataelxsi.co.in",
        "primary_skill": "react,jquery",
        "other_skill": "javascript",
        "certifications": "null",
        "summary": "Senior Engineer -mcv",
        "reviewer_id": null,
        "assign_id": 0,
        "batch_id": 0,
        "status": 3,
        "ondelete": 1
    },
    {
        "id": 6,
        "emp_id": "31770",
        "name": "abnit",
        "trainings": null,
        "grade": "h",
        "emp_email": "abnit@tataelxsi.co.in",
        "primary_skill": "react,jquery",
        "other_skill": "javascript",
        "certifications": "null",
        "summary": "Senior Engineer -mcv",
        "reviewer_id": null,
        "assign_id": 0,
        "batch_id": 0,
        "status": 3,
        "ondelete": 1
    },
    {
        "id": 9,
        "emp_id": "317711",
        "name": "test",
        "trainings": null,
        "grade": "h",
        "emp_email": "test@tataelxsi.co.in",
        "primary_skill": "react,jquery",
        "other_skill": "javascript",
        "certifications": "null",
        "summary": "Senior Engineer -mcv",
        "reviewer_id": null,
        "assign_id": 0,
        "batch_id": 0,
        "status": 3,
        "ondelete": 1
    },
    {
        "id": 10,
        "emp_id": "317712",
        "name": "testtt",
        "trainings": null,
        "grade": "h",
        "emp_email": "testtt@tataelxsi.co.in",
        "primary_skill": "react,jquery",
        "other_skill": "javascript",
        "certifications": "null",
        "summary": "Senior Engineer -mcv",
        "reviewer_id": null,
        "assign_id": 0,
        "batch_id": 0,
        "status": 3,
        "ondelete": 1
    },
    {
        "id": 11,
        "emp_id": "31771222",
        "name": "test123",
        "trainings": null,
        "grade": "h",
        "emp_email": "testtt@tataelxsi.co.in",
        "primary_skill": "react,jquery",
        "other_skill": "javascript",
        "certifications": "null",
        "summary": "Senior Engineer -mcv",
        "reviewer_id": null,
        "assign_id": 0,
        "batch_id": 0,
        "status": 3,
        "ondelete": 1
    },
    {
        "id": 12,
        "emp_id": "31771223",
        "name": "test123",
        "trainings": null,
        "grade": "h",
        "emp_email": "testtt@tataelxsi.co.in",
        "primary_skill": "",
        "other_skill": "",
        "certifications": "",
        "summary": "",
        "reviewer_id": null,
        "assign_id": 0,
        "batch_id": 0,
        "status": 3,
        "ondelete": 1
    },
    {
        "id": 13,
        "emp_id": "3177122444",
        "name": "test123",
        "trainings": null,
        "grade": "h",
        "emp_email": "testtt@tataelxsi.co.in",
        "primary_skill": "",
        "other_skill": "",
        "certifications": "",
        "summary": "",
        "reviewer_id": null,
        "assign_id": 0,
        "batch_id": 0,
        "status": 3,
        "ondelete": 1
    }
  ];


   this.setState({
    ...this.state,
    data:newjionersdata
   })
   // up to here

  }


  render() {
    return (
      <div>

<div className="d-flex justify-content-between" style={{width:"19vw"}}>
       <div>
       <h5>New Joiners</h5>
        </div>   
       <div onClick={this.handleShow} >
     <span style={{color:'blue',cursor:'pointer'}}>View All</span>
        </div>  
         </div>
        <Modal show={this.state.show} onHide={this.handleClose} animation={false}>
          <Modal.Header>
            <Modal.Title>All New Joiners</Modal.Title>
            <div onClick={this.handleClose} style={{cursor:'pointer'}}><XCircle color="black" size={'20'}/></div>

          </Modal.Header>
          <Modal.Body>  <div>
            <Table striped bordered hover size="sm">
              <thead>
                <tr>
                  <th>Emp ID</th>
                  <th>Name</th>
                  <th>SF Assigned</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {this.state.data ? this.state.data.map((candidate) => {
                  return (
                    <tr>
                      <td>{candidate.emp_id}</td>
                      <td>{candidate.name}</td>
                      <td>{candidate.reviewer_id}</td>
                      <td><button className="btn btn-sm btn-primary">Details</button></td>
                    </tr>
                  );
                }): null}
              </tbody>
            </Table>
          </div></Modal.Body>
        </Modal>
        <div>
          <Table striped bordered hover size="sm">
            <thead>
              <tr>
                <th>Emp ID</th>
                <th>Name</th>
                <th>SF Assigned</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
                {this.state.data ? this.state.data.slice(0,3).map((candidate) => {
                  return (
                    <tr>
                      <td>{candidate.emp_id}</td>
                      <td>{candidate.name}</td>
                      <td>{candidate.reviewer_id}</td>
                      <td><button className="btn btn-sm btn-primary">Details</button></td>
                    </tr>
                  );
                }): null}
              </tbody>
          </Table>
        </div>
      </div>
    );
  }
}

export default NewJoiners;
