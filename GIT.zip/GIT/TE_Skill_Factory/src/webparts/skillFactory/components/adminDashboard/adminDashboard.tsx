import * as React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import LeftPanel from "../shared/leftpanel/leftpanel";
import MentorListSlider from "./mentor/MentorList";
import CandidateTable from "./candidate/CandidateTable";
import NewJoiners from "./new-joiners/newJoiners";
import BatchChart from "./chats/batchChat";
import Card from "./card/Card"

class AdminDashboard extends React.Component {
  render() {
    return (
      <Container fluid={true}>
        <Row>
          <Col sm={3} bsPrefix="leftPanel col">
            <LeftPanel menuData="adminDashboard" />
          </Col>
          <Col sm={9}>
            <div className="rightContainer">
              <h3>Good Morning  Nihar !</h3>
              <Row>
                <Col>
                  <Card/>
                </Col>
                <Col>
                <BatchChart />
                </Col>
                <Col xs lg="2">
                  {/* <h5>New Joiners</h5> */}
                  <NewJoiners />
                </Col>
              </Row>
              <Row>
                <div className="mentCont col-sm-12">
                  {/* <h5>Reviewers / Mentors</h5> */}
                  <MentorListSlider />
                  {/* <CandidateTable /> */}
                  {/* <Reviewer /> */}
                </div>
              </Row>
            </div>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default AdminDashboard;
