import * as React from "react";
import Chart from 'react-apexcharts';

class BatchChart extends React.Component {
  constructor(props) {
    super(props);

    this.state = {    
      series: [60, 80],
      options: {
        chart: {
          height: 300,
          type: 'radialBar',
        },
        plotOptions: {
          radialBar: {
            dataLabels: {
              name: {
                fontSize: '22px',
              },
              value: {
                fontSize: '16px',
              },
              total: {
                show: true,
                label: 'Total',
                formatter: function (w) {
                  // By default this function returns the average of all series. The below is just an example to show the use of custom formatter function
                  return 294
                }
              }
            }
          }
        },
        labels: ['Courses', 'Assignments'],
      },
    
    
    };
  }

  render() {
    // const options = {
    //   chart: {
    //     id: "basic-bar",
    //   },
    //   xaxis: {
    //     categories: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998],
    //   },
    // };
    // const series = [
    //   {
    //     name: "series-1",
    //     data: [30, 40, 45, 50, 49, 60, 70, 91],
    //   },
    // ];
    return (
      <div className="chart">
      <Chart options={this.state.options} series={this.state.series} type="radialBar" height={200} />
    </div>
    );
  }
}

export default BatchChart;
