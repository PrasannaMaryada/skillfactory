import * as React from "react";
import Table from "react-bootstrap/Table";
import Slider from 'react-slick'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'
import { Link } from "react-router-dom"
import { Modal } from "react-bootstrap";
import { XCircleFill } from "react-bootstrap-icons";

const MentorSliderdata = [
  {
    id: 1,
    active: true,
    name: "John",
    icon: "https://randomuser.me/api/portraits/men/35.jpg",
    "EmpID": "33323",
    "Name": "John"
  },
  {
    id: 2,
    name: "Aman",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/34.jpg",
    "EmpID": "33323",
    "Name": "Aman"
  },
  {
    id: 3,
    name: "Rahul",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/40.jpg",
    "EmpID": "33323",
    "Name": "Rahul"
  },
  {
    id: 4,
    name: "Amar",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/22.jpg",
    "EmpID": "33323",
    "Name": "Amar"
  },
  {
    id: 5,
    name: "Pavan",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/32.jpg",
    "EmpID": "33323",
    "Name": "Pavan"
  },
  {
    id: 6,
    name: "Arjun",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/40.jpg",
    "EmpID": "33323",
    "Name": "Arjun"
  },
  {
    id: 7,
    name: "John",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/42.jpg",
    "EmpID": "33323",
    "Name": "John"
  },
  {
    id: 8,
    name: "Aman",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/55.jpg",
    "EmpID": "33323",
    "Name": "Aman"
  },
  {
    id: 9,
    name: "Rahul",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/54.jpg",
    "EmpID": "33323",
    "Name": "Rahul"
  },
  {
    id: 10,
    name: "Amar",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/41.jpg",
    "EmpID": "33323",
    "Name": "Amar"
  },
  {
    id: 11,
    name: "Pavan",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/42.jpg",
    "EmpID": "33323",
    "Name": "Pavan"
  },
  {
    id: 12,
    name: "Arjun",
    active: false,
    icon: "https://randomuser.me/api/portraits/men/39.jpg",
    "EmpID": "33323",
    "Name": "Arjun"
  }
];


const CandidateData = [
  {
    "id": 1,
    "name": "Aman",
    "icon": "images/dp.png",
    "skills": "JavaScript",
    "CC": "course 1, course 1",
    "mentor_id": 1,
    "emp_id": 20201
  },
  {
    "id": 2,
    "name": "Arun",
    "icon": "images/dp.png",
    "skills": "JavaScript,Java",
    "CC": "course 1, course 1",
    "mentor_id": 1,
    "emp_id": 20201
  },
  {
    "id": 3,
    "name": "Bibek",
    "icon": "images/dp.png",
    "skills": "JavaScript,Spfx",
    "CC": "course 1, course 1",
    "mentor_id": 2,
    "emp_id": 20201
  },
  {
    "id": 4,
    "name": "Ramesh",
    "icon": "images/dp.png",
    "skills": "JavaScript, Angular",
    "CC": "course 1, course 1",
    "mentor_id": 2,
    "emp_id": 20201
  },
  {
    "id": 5,
    "name": "Arbin",
    "icon": "images/dp.png",
    "skills": "JavaScript, React",
    "CC": "course 1, course 1",
    "mentor_id": 3,
    "emp_id": 20201
  },
  {
    "id": 6,
    "name": "Randhir",
    "icon": "images/dp.png",
    "skills": "JavaScript,CSS",
    "CC": "course 1, course 1",
    "mentor_id": 4,
    "emp_id": 20201
  },
  {
    "id": 6,
    "name": "Randhir",
    "icon": "images/dp.png",
    "skills": "JavaScript,CSS",
    "CC": "course 1, course 1",
    "mentor_id": 3,
    "emp_id": 20201
  },
  {
    "id": 7,
    "name": "Aman",
    "icon": "images/dp.png",
    "skills": "JavaScript",
    "CC": "course 1, course 1",
    "mentor_id": 6,
    "emp_id": 20201
  },
  {
    "id": 8,
    "name": "Arun",
    "icon": "images/dp.png",
    "skills": "JavaScript,Java",
    "CC": "course 1, course 1",
    "mentor_id": 5,
    "emp_id": 20201
  },
  {
    "id": 9,
    "name": "Bibek",
    "icon": "images/dp.png",
    "skills": "JavaScript,Spfx",
    "CC": "course 1, course 1",
    "mentor_id": 7,
    "emp_id": 20201
  },
  {
    "id": 10,
    "name": "Ramesh",
    "icon": "images/dp.png",
    "skills": "JavaScript, Angular",
    "CC": "course 1, course 1",
    "mentor_id": 8,
    "emp_id": 20201
  },
  {
    "id": 10,
    "name": "Ramesh",
    "icon": "images/dp.png",
    "skills": "JavaScript, Angular",
    "CC": "course 1, course 1",
    "mentor_id": 9,
    "emp_id": 20201
  },
  {
    "id": 11,
    "name": "Arbin",
    "icon": "images/dp.png",
    "skills": "JavaScript, React",
    "CC": "course 1, course 1",
    "mentor_id": 9,
    "emp_id": 20201
  },
  {
    "id": 12,
    "name": "Randhir",
    "icon": "images/dp.png",
    "skills": "JavaScript,CSS",
    "CC": "course 1, course 1",
    "mentor_id": 10,
    "emp_id": 20201
  },
  {
    "id": 13,
    "name": "Arbin",
    "icon": "images/dp.png",
    "skills": "JavaScript, React",
    "CC": "course 1, course 1",
    "mentor_id": 11,
    "emp_id": 20201
  },
  {
    "id": 13,
    "name": "Arbin",
    "icon": "images/dp.png",
    "skills": "JavaScript, React",
    "CC": "course 1, course 1",
    "mentor_id": 12,
    "emp_id": 20201
  },
  {
    "id": 14,
    "name": "Randhir",
    "icon": "images/dp.png",
    "skills": "JavaScript,CSS",
    "CC": "course 1, course 1",
    "mentor_id": 12,
    "emp_id": 20201
  }
];



export interface props {
  id: string
}

class MentorListSlider extends React.Component<any, any, any> {

  constructor(props: any) {
    super(props);

    this.state = {
      id: "",
      mentor: 1,
      active: "",
      show: false
    }

  }
  handleClick = (id, index) => {
    this.setState({
      ...this.state,
      id: id,
      mentor: 0,
      active: false
    })
    MentorSliderdata.forEach((x, i) => {
      if (i === index) {
        x.active = true
      } else {
        x.active = false
      }
    })

  }
  handleShow = () => {
    this.setState({
      ...this.state,
      show: true
    })
  }

  handleClose = () => {
    this.setState({
      ...this.state,
      show: false
    })
  }
  render() {
    const settings = {
      arrows: true,
      infinite: false,
      slidesToShow: 7,
      slidesToScroll: 7,
      speed: 500,
      className: 'slides',
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 4,
            initialSlide: 4,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
          },
        },
      ],
    }


    let can = CandidateData.map((c) => {
      if (this.state.id === c.mentor_id) {
        return c
      }
      if (this.state.mentor === c.mentor_id) {
        return c
      }
    })

    let res = can.filter(n => n);

    let id = MentorSliderdata.map((c) => {
      if (this.state.id === c.id) {
        return c.name
      }
      if (this.state.mentor === c.id) {
        return c.name
      }
    })
    let name = id.filter(n => n);
    return (
      <div>
        {/* <Modal
          size="lg"
          show="true"
          aria-labelledby="example-modal-sizes-title-lg"
        >
          <Modal.Header>
            <Modal.Title>Mentor/Reviewer</Modal.Title>
          </Modal.Header>

          <Modal.Body> */}
        <div className="d-flex justify-content-between">
          <div>
            <h5>Reviewers / Mentors</h5>
          </div>
          <div onClick={this.handleShow} >
            <span style={{ color: 'blue', cursor: 'pointer' }}>View All</span>
          </div>
        </div>
        <Slider {...settings}>

          {MentorSliderdata.map((mentor, index) => {
            return (
              <div className={"slider_cont " + (mentor.active ? 'active' : '')} onClick={(e) => this.handleClick(mentor.id, index)}>
                <div>
                  <img width="100%" src={mentor.icon} alt="dp" />
                </div>
                <div>{mentor.name}</div>
              </div>
            )
          })}
        </Slider>
        <div>
          <h5>{name}'s Team ({res.length} Candidates)</h5>
          <Table striped bordered hover size="sm">
            <thead>
              <tr>
                <th>Emp ID</th>
                <th>Name</th>
                <th>Skills</th>
                <th>Completed Courses</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {CandidateData.map((candidate) => {
                if (this.state.id === candidate.mentor_id) {
                  return (
                    <tr>
                      <td>{candidate.id}</td>
                      <td>{candidate.name}</td>
                      <td>{candidate.skills}</td>
                      <td>{candidate.CC}</td>
                      <td>
                        <Link to={'/Profile/' + candidate.emp_id}>
                          <button className="btn btn-sm btn-primary">Details</button>
                        </Link>
                      </td>
                    </tr>
                  );
                }

                if (this.state.mentor === candidate.mentor_id) {
                  return (
                    <tr>
                      <td>{candidate.id}</td>
                      <td>{candidate.name}</td>
                      <td>{candidate.skills}</td>
                      <td>{candidate.CC}</td>
                      <td>
                        <Link to={'/Profile/' + candidate.emp_id}>
                          <button className="btn btn-sm btn-primary">Details</button>
                        </Link>
                      </td>
                    </tr>
                  );
                }
              })}
            </tbody>
          </Table>
        </div>
        <Modal show={this.state.show} onHide={this.handleClose} animation={false}>
          <Modal.Header >
            <Modal.Title>All Reviwes</Modal.Title>
            <div onClick={this.handleClose} style={{ cursor: 'pointer' }}><XCircleFill color="black" size={'30'} /></div>
          </Modal.Header>
          <Modal.Body>  <div>
            <Table striped bordered hover size="sm">
              <thead>
                <tr>
                  <th>Emp ID</th>
                  <th>Name</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {MentorSliderdata.map((candidate) => {
                  return (
                    <tr>
                      <td>{candidate.EmpID}</td>
                      <td>{candidate.Name}</td>
                      <td>
                        <Link to={'/Profile/' + candidate.EmpID}>

                          <button className="btn btn-sm btn-primary">Details</button>

                        </Link>
                        {/* <button className="btn btn-sm btn-primary">Details</button> */}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          </div></Modal.Body>
        </Modal>
      </div>
    )
  }
}

export default MentorListSlider
