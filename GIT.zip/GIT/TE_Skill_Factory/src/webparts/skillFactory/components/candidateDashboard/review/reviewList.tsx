import * as React from 'react';
import './reviewList.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col'
import { Button, ListGroup } from 'react-bootstrap';


class ReviewList extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
    }
    render() {


        return (
            <ListGroup style={{ backgroundColor: '#DCDCDC', borderRadius: 10, padding: '15px 15px 15px 10px' }}>
                {this.props.data.map((data: any, idx: any) => (
                    <ListGroup.Item variant={idx % 2 == 0 ? 'light' : "secondary"}>
                        <Row >
                            <Col className='d-flex justify-content-start mt-2 ' sm={12} xs={12}>
                                <p className=" fw-bolder desc_1" style={{ fontSize: 14 }}>{data.comments}</p>
                            </Col>

                        </Row>
                    </ListGroup.Item>
                ))}
            </ListGroup>
        )
    }
}

export default ReviewList