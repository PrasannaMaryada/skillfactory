import * as React from 'react';
import './completedCoursesTable.css';

import Table from 'react-bootstrap/Table';
import { Button, PageItem, Pagination} from 'react-bootstrap';


class CompletedCoursesTable extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            startIndex : "",
            endIndex : "",
            currentPage : 1,
            rowsPerPage: 4,
            page: 1

        }

    }
    render() {
        const { rowsPerPage, page } = this.state
        const endOffSet = Math.min(this.props.data.length, rowsPerPage * page)
    
        const tableData = this.props.data.slice((page - 1) * rowsPerPage, endOffSet)

        // console.log(tableData,'test')
        

    //    this.setState({startIndex:Math.random(this.props.data.length/)});
    //    this.setState({endIndex:this.state.startIndex + })


        return (
            <>
            <Table striped hover >
                <thead >
                    <tr>
                        <th>Course Name</th>
                        <th>Duration</th>
                    </tr>
                </thead>
                <tbody>
                    {tableData.map((item: any) =>
                 (
                        <tr>
                            <td>{item.course_name}</td>
                            <td>{item.duration}</td>
                            <td><Button className='btn btn-default btn-block' variant="primary" size="sm">Details</Button>{' '}
                            </td>
                        </tr>
                    ))
                    }
                
                  
                </tbody>
                
            </Table>

            {/* <tr>
                    <td>Moorthy</td>
            </tr> */}
            
            {/* <Pagination>
                {this.props.data.slice(0,3).map((item:any)=>(
                <PageItem>{item}</PageItem>
                ))}
            </Pagination> */}
            
            {/* <Pagination>
            
      <Pagination.First />
      <Pagination.Prev />
      <Pagination.Item>{1}</Pagination.Item>
      <Pagination.Ellipsis />

      <Pagination.Item>{6}</Pagination.Item>
      <Pagination.Item>{7}</Pagination.Item>
      <Pagination.Item active>{8}</Pagination.Item>
      <Pagination.Item>{9}</Pagination.Item>
      <Pagination.Item disabled>{10}</Pagination.Item>

      <Pagination.Ellipsis />
      <Pagination.Item>{20}</Pagination.Item>
      <Pagination.Next />
      <Pagination.Last />
    </Pagination> */}

<div className='pagination-button-group'>
                    <div style={{textAlign:'right'}}>
                    <Button
                      size="sm"
                      style={{ marginLeft: '12px' }}
                      variant="outline-info"
                      disabled={page <= 1}
                      onClick={() => this.setState({ page: 1 })}
                    >
                      {`<<`}
                    </Button>
                    <Button
                      size="sm"
                      style={{ marginLeft: '12px' }}
                      variant="outline-info"
                      disabled={page <= 1}
                      onClick={() => this.setState({ page: page - 1 })}
                    >
                      {`<`}
                    </Button>
                    <span style={{ marginLeft: '8px' }}>{page} </span>
                    <Button
                      size="sm"
                      style={{ marginLeft: '8px' }}
                      variant="outline-info"
                      disabled={(page * rowsPerPage) >= this.props.data.length}
                      onClick={() => this.setState({ page: page + 1 })}
                    >
                      {`>`}
                    </Button>
                    <Button
                      size="sm"
                      style={{ marginLeft: '12px' }}
                      variant="outline-info"
                      onClick={() => this.setState({ page: Math.floor(this.props.data.length / 10) })}
                    >
                      {`>>`}
                    </Button>
                    </div>
                  </div>

            </>
        )
    }
}

export default CompletedCoursesTable