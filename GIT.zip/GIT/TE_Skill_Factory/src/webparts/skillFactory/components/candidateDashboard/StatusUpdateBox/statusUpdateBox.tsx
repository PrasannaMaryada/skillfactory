import * as React from "react";
import "./statusUpdateBox.css";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { Button, Card } from "react-bootstrap";
import { Component } from "react";




interface AddProps{

}
 export interface AddState {
  inputValue : any;
 }
class StatusUpdateBox extends React.Component< AddProps,AddState>

{

  constructor(props) {
    super(props);
   
    this.state = { 
  
        inputValue:'',
        
        
      };
    this.handleClick = this.handleClick.bind(this);
  }
  
  




  handleChange =(e) =>{
    this.setState({ 
      
      inputValue : (e.target.value)
    });
    //console.log("inputvalue",this.state.inputValue)
  }
  
  handleClick() {
    
    fetch('https://10.1.2.136:3001/api/dailyStatus/create', {
      method: 'POST',
      body: JSON.stringify({

					
          "user_id": 32775,
          "status":this.state.inputValue,
            // ondate:new Date().toDateString()
				
        
        
      }),

      headers: {
        'Content-type': 'application/json',
      },
    })
      .then((response) => response.json())
      .then((json) => (alert('Updated Status Successfully')));
      
  }

previousStatus=()=>{
  alert('Previous Status History')
}




  render() {

   
    return (
      <div
        className="p-2"
        style={{ backgroundColor: "rgb(169, 231, 251)", borderRadius: 10 }}
      >
        <Col className="d-flex justify-content-end p-2">
          <a className=" fw-bolder text-primary" style={{ fontSize: 12, color:"black" }} href="https://tataelxsi.sharepoint.com/sites/TATA_ELXSI_SKILL_FACTORY/_layouts/15/workbench.aspx#/candidateStatusHistory">
            Previous Status History
          </a>
        </Col>
        <Card className="box-fullsize">
          <Card.Body>


            <textarea
              id="w3review"
              name="w3review"
              rows={6}
              cols={50}
              style={{ border: "0px", width: "100%" }}
              value={this.state.inputValue}
              onChange={this.handleChange}

              
            >
             
            </textarea>
          </Card.Body>
        </Card>
        <div className="d-flex justify-content-end p-2 ">
          <Button variant="primary" className="d-flex align-self-end" onClick={this.handleClick}>
            Update
          </Button>
        </div>
      </div>
    );
  }
}

export default StatusUpdateBox;
