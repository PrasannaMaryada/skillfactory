import * as React from "react";
// import styles from "./SkillFactory.module.scss";
import { ISkillFactoryProps } from "./ISkillFactoryProps";
import { escape } from "@microsoft/sp-lodash-subset";
// import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HashRouter, Route, Switch } from "react-router-dom";
import Welcome from "./welcome/welcome";
import AdminDashboard from "./adminDashboard/adminDashboard";
import ReviewerDashboard from "./reviewerDashboard/reviewerDashboard";
import ManageCandidates from "./manage-candidates/manageCandidates";
import CandidateDashboard from "./candidateDashboard/candidateDashboard";
import CandidateProfilePage from "./candidateProfile/candidateProfilePage";
import Login from "./Login/Login";
import CandidateStatusHistory from "./candidateDashboard/candidateStatusHistory/CandidateStatusHistory";
import "bootstrap/dist/css/bootstrap.min.css";
import "./shared/globalStyle.css";
import EditProfile from "./editProfile/EditProfile";


export default class SkillFactory extends React.Component<
  ISkillFactoryProps,
  {}
> {
  public render(): React.ReactElement<ISkillFactoryProps> {
    const {
      description,
      isDarkTheme,
      environmentMessage,
      hasTeamsContext,
      userDisplayName,
    } = this.props;

    return (
      <div className="App">
        <HashRouter>
          <Switch>
            <Route path="/welcome" component={() => <Welcome />}></Route>
            <Route path="/adminDashboard" component={() => <AdminDashboard />}></Route>
            <Route path="/editProfile" component={() => <EditProfile />}></Route>
            <Route path="/manageCandidate" component={() => <ManageCandidates />}></Route>
            <Route path="/reviewerDashboard" component={() => <ReviewerDashboard />}></Route>
            <Route path="/candidateDashboard" component={() => <CandidateDashboard />}></Route>
            <Route path="/Profile" component={() => <CandidateProfilePage />}></Route>
            <Route path="/candidateStatusHistory" component={() => <CandidateStatusHistory />}></Route>
            <Route path="/" component={() => <Login />}></Route>
          </Switch>
        </HashRouter>
      </div>
      // <section className={`${styles.skillFactory} ${hasTeamsContext ? styles.teams : ''}`}>
      //   <div className={styles.welcome}>
      //     <img alt="" src={isDarkTheme ? require('../assets/welcome-dark.png') : require('../assets/welcome-light.png')} className={styles.welcomeImage} />
      //     <h2>Well done, {escape(userDisplayName)}!</h2>
      //     <div>{environmentMessage}</div>
      //     <div>Web part property value: <strong>{escape(description)}</strong></div>
      //   </div>
      //   <div>
      //     <h3>Welcome to SharePoint Framework!</h3>
      //     <p>
      //       The SharePoint Framework (SPFx) is a extensibility model for Microsoft Viva, Microsoft Teams and SharePoint. It&#39;s the easiest way to extend Microsoft 365 with automatic Single Sign On, automatic hosting and industry standard tooling.
      //     </p>
      //     <h4>Learn more about SPFx development:</h4>
      //     <ul className={styles.links}>
      //       <li><a href="https://aka.ms/spfx" target="_blank" rel="noreferrer">SharePoint Framework Overview</a></li>
      //       <li><a href="https://aka.ms/spfx-yeoman-graph" target="_blank" rel="noreferrer">Use Microsoft Graph in your solution</a></li>
      //       <li><a href="https://aka.ms/spfx-yeoman-teams" target="_blank" rel="noreferrer">Build for Microsoft Teams using SharePoint Framework</a></li>
      //       <li><a href="https://aka.ms/spfx-yeoman-viva" target="_blank" rel="noreferrer">Build for Microsoft Viva Connections using SharePoint Framework</a></li>
      //       <li><a href="https://aka.ms/spfx-yeoman-store" target="_blank" rel="noreferrer">Publish SharePoint Framework applications to the marketplace</a></li>
      //       <li><a href="https://aka.ms/spfx-yeoman-api" target="_blank" rel="noreferrer">SharePoint Framework API reference</a></li>
      //       <li><a href="https://aka.ms/m365pnp" target="_blank" rel="noreferrer">Microsoft 365 Developer Community</a></li>
      //     </ul>
      //   </div>
      // </section>
    );
  }
}
