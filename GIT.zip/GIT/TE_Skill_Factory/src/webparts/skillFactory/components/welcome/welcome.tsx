import * as React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";


class Welcome extends React.Component {
  render() {
    return (
      <Container fluid={true}>
        <Row>
          <Col sm={12}>
            <div className="headWel">
              <div className="container py-2 h-100">
                <div className="row d-flex justify-content-center align-items-center h-100">
                  <div>
                    <div className="card">
                      <div className="card-body p-4">
                        <div className="d-flex text-black">
                          <div className="flex-shrink-0">
                            <img
                              src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-profiles/avatar-1.webp"
                              alt="Generic placeholder image"
                              className="img-fluid prof"
                            />
                          </div>
                          <div className="flex-grow-1 ms-3" style={{ textAlign: "left" }}>
                            <h3 className="mb-4">Hi Nihar!</h3>
                            <h5 className="mb-1">
                              Welcome to Skill Factory Training
                            </h5>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="container py-4">
              <h5>About Skill Factory</h5>
              <p>Skill Factory created an organised, adaptable and guided learning programme that offers a variety of skilled courses such as E-Learning, Leadership, Communication Skills, Critical Thinking, Communication Skills, Teamwork & Adaptability and so on. Training is associated with quick changes in organizational effectiveness through organized instruction, whereas development is associated with the advancement of long-term organizational and individual goals. </p>
              <p>Training and development is an internal process that influences an employee's behaviour and willingness to meet company objectives. Creating a motivating environment inside an organisation can assist in ensuring staff achieve their peak productivity. Motivation can lead to a more engaged workforce, which improves both individual and organisational performance.</p>
              <p>Our training is supported by well-equipped classrooms and skilled facilitators who provide personalized attention, advice, and support throughout the learning process. In addition to the learnings, we provide free Udemy course coupons as well and also coupons for other learning environments.</p>
            </div>
         
            <ul className="steps-panel">
            <li className="step1">
                <a>
                  <div>
                    <strong>Beginner</strong>
                    <p>Here you will learn intoduction to web technologies</p>
                  </div>
                </a>
              </li>
              <li className="step2">
                <a>
                  <div>
                    <strong>Intermediate</strong>
                    <p>Here you can get Advanced level of skills like frameworks in front end.</p>
                  </div>
                </a>
              </li>
              <li className="step3">
                <a>
                  <div>
                    <strong>Advanced</strong>
                    <p>Here you will get real time applicaton handson experince</p>
                  </div>
                </a>
              </li>
              <li className="step4">
                <a>
                  <div>
                    <strong>Bootcamp</strong>
                    <p>Here you may need to build some realistic applications.</p>
                  </div>
                </a>
              </li>
            </ul>
            <div className="row d-flex justify-content-center align-items-center py-5">
               <Link className="w-25 btn btn-primary" to="/adminDashboard">Continue to Profile</Link>
              </div>
          </Col>
        </Row>
       
      </Container>
    );
  }
}

export default Welcome;
