import * as React from "react";
import Card from 'react-bootstrap/Card';
// import CandidatesSliderdata from './candidatesSliderdata'
const data = [
  { task: "complete", name: "Project Name", view: "View" },
  { task: "pending", name: "Project Name", view: "Review" },
  { task: "pending", name: "Project Name", view: "Review" }
]

class CurrentAssignments extends React.Component {
  render() {  
    return (
      <div className='cards-view'>
      <div className='card-text'>
          <h4>Johnny Active Assessments</h4>
          <p>view Johnny profile</p>
      </div>
      <div className='cards'>
          {data.map((e) => (
              <Card style={{ width: '30%', marginLeft:"1%",marginRight:"1%" }} className="card">
                  <Card.Body className='card-body'>
                      <button className='task-button'>{e.task}</button>
                      <Card.Text className='cards-text'>
                          {e.name}
                      </Card.Text>
                      <button className='card-view-button'>{e.view}</button>
                  </Card.Body>
              </Card>
          ))}
      </div>
  </div>
    )
  }
}

export default CurrentAssignments
