import * as React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Table from "react-bootstrap/Table";
import LeftPanel from "../shared/leftpanel/leftpanel";
import Badge from "react-bootstrap/Badge";
import ListGroup from "react-bootstrap/ListGroup";
import Dropdown from "react-bootstrap/Dropdown";
import Button from 'react-bootstrap/Button';
import {Modal } from 'react-bootstrap';
import "./createNewBatch.css";
const CandidateList = [
  {
    id: 27167,
    name: "Aman",
    icon: "images/dp.png",
    skills: "JavaScript,React,JavaScript, React",
    CC: 1,
    mentor_id: 1,
  },
  {
    id: 27168,
    name: "Arun",
    icon: "images/dp.png",
    skills: "JavaScript,Java,JavaScript, React,JavaScript, React",
    CC: 2,
    mentor_id: 1,
  },
  {
    id: 27166,
    name: "Bibek",
    icon: "images/dp.png",
    skills: "JavaScript,Spfx,JavaScript, React,JavaScript, React",
    CC: 2,
    mentor_id: 2,
  },
  {
    id: 27165,
    name: "Ramesh",
    icon: "images/dp.png",
    skills: "JavaScript, Angular,JavaScript, React,JavaScript, React",
    CC: 2,
    mentor_id: 2,
  },
  {
    id: 27164,
    name: "Arbin",
    icon: "images/dp.png",
    skills: "JavaScript, React,JavaScript, React",
    CC: 2,
    mentor_id: 3,
  },
  {
    id: 27163,
    name: "Randhir",
    icon: "images/dp.png",
    skills: "JavaScript,JavaScript, React,JavaScript, React,CSS",
    CC: 2,
    mentor_id: 4,
  },
];

interface IProps {}

interface IState {
  List?: {
    [x: string]: any;
    id: number;
    name: string;
    icon: string;
    skills: string;
    CC: number;
    mentor_id: number;
  }[];
  MasterChecked?: boolean;
  SelectedList?: {
    [x: string]: any;
    id: number;
    name: string;
    icon: string;
    skills: string;
    CC: number;
    mentor_id: number;
  }[];
  openmodalstate:boolean;
}
class ManageCandidates extends React.Component<IProps, IState> {
  constructor(props: IProps) {
    super(props);
    this.state = {
      List: CandidateList,
      MasterChecked: false,
      SelectedList: [],
      openmodalstate:false
    };
  }
  openmodal(){
    this.setState({
       openmodalstate:!this.state.openmodalstate 
    })
}
  // Select/ UnSelect Table rows
  onMasterCheck(e) {
    let tempList = this.state.List;
    // Check/ UnCheck All Items
    tempList.map((candidate) => (candidate.selected = e.target.checked));

    //Update State
    this.setState({
      MasterChecked: e.target.checked,
      List: tempList,
      SelectedList: this.state.List.filter((e) => e.selected),
    });
  }

  // Update List Item's state and Master Checkbox State
  onItemCheck(e, item) {
    let tempList = this.state.List;
    tempList.map((candidate) => {
      if (candidate.id === item.id) {
        candidate.selected = e.target.checked;
      }
      return candidate;
    });

    //To Control Master Checkbox State
    const totalItems = this.state.List.length;
    const totalCheckedItems = tempList.filter((e) => e.selected).length;

    // Update State
    this.setState({
      MasterChecked: totalItems === totalCheckedItems,
      List: tempList,
      SelectedList: this.state.List.filter((e) => e.selected),
    });
  }
  updateCandidateAssignment(){
    
  }
  render() {
    return (
      <Container fluid={true}>
        <Row>
          <Col sm={3} bsPrefix="leftPanel col">
            <LeftPanel menuData="manageCandidate"/>
          </Col>
          <Col sm={9}>
            <div className="rightContainer">
              <h3>Good Morning  nihar !</h3>
              <div className="CandiCont">
                <Row>
                  <Col sm={12}>
                    <div>
                      <h5>Candidates</h5>
                      <Table striped bordered hover size="sm" className="bg-white">
                        <thead>
                          <tr>
                            <th>
                              <input
                                type="checkbox"
                                className="form-check-input"
                                checked={this.state.MasterChecked}
                                id="mastercheck"
                                onChange={(e) => this.onMasterCheck(e)}
                              />
                            </th>
                            <th>Emp </th>
                            <th>Name</th>
                            <th>Skills</th>
                          </tr>
                        </thead>
                        <tbody>
                          {this.state.List.map((candidate) => (
                            <tr
                              key={candidate.id}
                              className={candidate.selected ? "selected" : ""}
                            >
                              <th scope="row">
                                <input
                                  type="checkbox"
                                  checked={candidate.selected}
                                  className="form-check-input"
                                  id="rowcheck{candidate.id}"
                                  onChange={(e) =>
                                    this.onItemCheck(e, candidate)
                                  }
                                />
                              </th>
                              <td>{candidate.id}</td>
                              <td>{candidate.name}</td>
                              <td>{candidate.skills}</td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </div>
                  </Col>
                </Row>
                <hr></hr>
                <div>
                  
                <button className="newbatchbutton btn btn-primary btn-sm newbatchbutton rounded-0" onClick={()=>this.openmodal()}>Create New Batch</button>
                  </div>
                
                <div>
                  
                  <h5>Actions</h5>
                  <div className="actCont">
                    <Row>
                      <Col sm={6}>
                        <ListGroup as="ol" numbered>
                          <div className="fw-bold">Selected Candidates</div>

                          {this.state.SelectedList.map((selectedCan) => (
                            <ListGroup.Item
                              as="li"
                              className="d-flex justify-content-between align-items-start"
                            >
                              <div className="ms-2 me-auto">
                                {selectedCan.name}
                              </div>
                              <span
                                className="badge rounded-pill bg-danger c-pointer"
                                onClick={(e) =>
                                  this.onItemCheck(e, selectedCan)
                                }
                              >
                                X
                              </span>
                            </ListGroup.Item>
                          ))}
                        </ListGroup>
                      </Col>
                      <Col sm={6}>
                        <div className="fw-bold">Reviewer</div>
                        <Dropdown>
                          <Dropdown.Toggle
                            variant="secondary"
                            id="dropdown-basic"
                          >
                            Select Reviewer
                          </Dropdown.Toggle>

                          <Dropdown.Menu>
                            <Dropdown.Item>
                              Nihar
                            </Dropdown.Item>
                            <Dropdown.Item>
                              Ajith
                            </Dropdown.Item>
                            <Dropdown.Item>
                              Vishnu
                            </Dropdown.Item>
                            <Dropdown.Item>
                              Abnit
                            </Dropdown.Item>
                            <Dropdown.Item>
                              Baburam
                            </Dropdown.Item>
                          </Dropdown.Menu>
                        </Dropdown>

                      </Col>
                    </Row>
                  <Row>
                    <Col md={{ span: 4, offset: 8 }}>
                    <Button variant="primary" className="mt-2" onClick={this.updateCandidateAssignment}>Update</Button>

                    </Col>
                  </Row>
                  </div>
                </div>
                
              </div>
            </div>
          </Col>
        </Row>
        <Modal show={this.state.openmodalstate} onHide={()=>this.openmodal()}>
        <Modal.Header closeButton={true} className="main_header">
            Create New Batch
        </Modal.Header>
        <Modal.Body className='body_styles'>
            
            <div className='maindiv'>
            <label className='Sdate'>Start Date:</label>
            <input className='input-styles' type="date"/>
            </div>
            <div className='maindiv'>
            <label className='Sdate' >End Date:</label>
            <input  className='input-styles' type="date"/>
            </div>
            <div className='maindiv'>
            <label className='Sdate-1'>Batch Name:</label>
            <input className='input-styles'placeholder='Enter Batch Name'  type="Text"/>
            </div>
            <div>
                <button className='button-1' onClick={()=>this.openmodal()}> Create Page</button>
            </div>
            
            
        </Modal.Body>
        
        {/* <Modal.Footer>
        
        </Modal.Footer> */}
        
       </Modal>
      </Container>
    );
  }
}

export default ManageCandidates;


