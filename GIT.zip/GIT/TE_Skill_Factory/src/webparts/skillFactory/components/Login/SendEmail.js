
import emailjs from '@emailjs/browser';

export const sendEmail = (e) => {
    emailjs.sendForm(
        'service_4mx3lgs',
        'template_t6n3yq6', e,
        'UysLYSwMPQ7nhhfv1')
        .then(
            (result) => { console.log(result.text); },
            (error) => {
                console.log(error.text);
            });
};



