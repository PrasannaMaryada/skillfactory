import { ConsoleListener } from '@pnp/logging';
import * as React from 'react';
import './Login.css';
import { NavLink } from 'react-router-dom';
import ReviewList from '../candidateDashboard/review/reviewList';
// import { times } from '@microsoft/sp-lodash-subset';
// import { Navigate } from "react-router-dom";
// import { useNavigate } from "react-router-dom";
import { sendEmail } from '../Login/SendEmail';
//import GoogleLogin from 'react-google-login';
//import ReactLoginMS from "react-ms-login";


class Login extends React.Component<any, any> {

  constructor(props: any){

    super(props);

  }

  myRef = React.createRef<HTMLFormElement>();

  state = {
    email: "",
    password: "",
    isLoading: false,
    userNameErrorMessage: "",
    passwordErrorMessage: "",
    isAdmin: true,
    error: {
      status: false,
      message: ""
    },
    status: 3,
    page: '',
    success: false
  };

  handleUsername = (e) => {
    this.setState({ email: e.target.value });
  }


  handlePassword = (e) => {
    this.setState({ password: e.target.value });
  };

  login = event => {
    event.preventDefault();
    if (this.state.email != '' && this.state.password != '') {
      sendEmail(this.myRef.current);
      localStorage.setItem("email", this.state.email)
      //this.handleClick(3);

    }
    else {
      if (this.state.email == '') {
        this.setState({ userNameErrorMessage: "Please Enter the Username" });
      }
      if (this.state.password == '') {
        this.setState({ passwordErrorMessage: "Please Enter the Password" });

      }
    }
  }

  componentDidUpdate(prevProps: Readonly<{}>, prevState: Readonly<{}>, snapshot?: any): void {

  }

  handleClick = (e) => {
    e.preventDefault();
    this.setState({page:'/candidate'});
    console.log(this.state.page);
    // switch (this.state.status) {
    //   case 0: {
    //     this.state.page = '/admin';
    //     window.location.replace("/admin")
    //   };
    //   case 1: {
    //     this.state.page = '/admin';
    //     window.location.replace("/admin")
    //   };
    //   case 2: {
    //     this.state.page = '/reviewer';
    //     window.location.replace("/reviewer")
    //   };
    //   case 3: {
    //     this.state.page = '/candidate';
    //     window.location.replace("/candidate")
    //   };
    // }
  }


  render() {
    const { email, password, isLoading, error, success } = this.state;

    // function showGmail() {

    //   return <GoogleLogin

    //     clientId="491004959702-3bgqo54pt777f77dgl7cqd6s7e7rii81.apps.googleusercontent.com"

    //     buttonText={'LOGIN WITH GOOGLE'}

    //     // onSuccess={responseGoogle}

    //     // onFailure={responseGoogle}

    //     cookiePolicy={"single_host_origin"}

    //     className="GOOGLE"



    //   />

    // }

    // function showMS() {

    //   return <ReactLoginMS

    //     clientId="ef6d8c0c-4968-4c20-866e-ac765ee9ea15"

    //     redirectUri="https://medium.com/zestgeek/login-with-github-and-microsoft-in-reactjs-e33ffbcd933"

    //     cssClass="ms-login"

    //     btnContent="LOGIN WITH MICROSOFT"

    //     responseType="token"

    //     handleLogin={data => console.log(data)}

    //   />

    // }
    return (
      <div className="login">
        <div className="Container content-wrapper">
          <div className="brand-logo">
            <img src="https://www.tataelxsi.com/storage/settings/December2021/n750u83PWIj8aGANE3yf.png" alt="Tata Elxsi" width="180" height="30"></img>
          </div>
          {/* <h4>Hello! let's get started</h4>
            <h6>Sign in to continue.</h6> */}
          <form ref={this.myRef} onSubmit={this.login}>
            <div className="form-group">
              <label className="col-form-label"><b>Your Emp ID</b></label><br />
              <input type="username" name="email" placeholder="Username" value={this.state.email} onChange={this.handleUsername} />
              <p className="ErrorMsg">{this.state.userNameErrorMessage}</p>
            </div>
            <div className='form-group'>
              <label className="col-form-label"><b>Password</b></label><br />
              <input type="password" name="password" placeholder="Password" value={this.state.password} onChange={this.handlePassword}>
              </input>
              <p className="ErrorMsg">{this.state.passwordErrorMessage}</p>
            </div>
            <div className='LoginBtn'>
              <button className="btn btn-primary btn-sm signin" type="submit" onClick={this.handleClick}><NavLink to={this.state.page}>SIGN IN </NavLink></button><br />
              {/* <button className="btn btn-primary btn-sm microsoft"><NavLink to={this.state.isAdmin ? this.state.page : "/welcome"}>Office 365 Login</NavLink></button>
              <div className="flex-container" style={{ display: 'flex', marginTop: '11px' }}>
                {
                  showGmail()
                }
                {
                  showMS()
                }
              </div> */}
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Login;