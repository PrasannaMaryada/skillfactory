/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable react/self-closing-comp */
/* eslint-disable @typescript-eslint/explicit-member-accessibility */
/* eslint-disable @typescript-eslint/typedef */
import * as React from 'react';
import Container from 'react-bootstrap/Container';
import  Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Table from 'react-bootstrap/Table';
import Form from 'react-bootstrap/Form';
import {AiOutlineMinus, AiOutlinePlus} from 'react-icons/ai';
import Button from 'react-bootstrap/Button';
import { Modal } from 'react-bootstrap';
import { BsFillPersonPlusFill,BsFillPersonLinesFill,BsFillPencilFill, BsPlusCircleFill}  from 'react-icons/bs';
import 'bootstrap/dist/css/bootstrap.min.css';
import './EditProfile.css';
import Dropdown  from '../shared/dropdown/Dropdown';

interface EditProfileProps{

}

interface EditProfileState{
  userData: object,
  primary_skill: object[]
  rowsData :any[];
  showHide:boolean;
  

}

export default class EditProfile extends React.Component<EditProfileProps, EditProfileState> {
 
  
  all_skills:string[] = ['HTML/CSS', 'Javascript', 'jQuery', 'React JS', 'Node JS'];
  proficiencies: string[] = ['Trained', 'Beginner', 'Intermediate', 'Expert'];
 

  constructor(props) {
    super(props); 
    this.state =  {
      userData: {
        name: "",
        employee_id:"",
        grade: "",
        email:"",
        primary_skills: [{skill:"HTML/CSS", proficiency:"Beginner"}],
        other_skills: "",
        professional_summary: [
          {project_name: "",
           duration: "", 
           roles: "", 
           skills: [] 
          }],
        certifications:"",
        trainings: ""
      },
      rowsData :[{
        project_name:'',
        duration:'',
        role:''  ,
        languages:''
    } ],
      primary_skill: [{skill: '', proficiency:''}],
      showHide: false,
    };
     this.addTableRows = this.addTableRows.bind(this);
     this.displaySkills = this.displaySkills.bind(this);
  }
 
  addPrimarySkills = () =>{
    console.log("Will Add Primary Skills");
    this.setState({primary_skill: [...this.state.primary_skill, {skill:"", proficiency:""}]})
  } 

  displaySkills = () =>{
    console.log("Will Show Primary Skills");
  } 
  // eslint-disable-next-line @typescript-eslint/explicit-member-accessibility
  submitHandler = (e: React.FormEvent<HTMLFormElement>) =>{
    e.preventDefault();
    const details = e.target;
    console.log(details);
    // const formData = Object.fromEntries(new FormData(details));
    // console.log(formData);
    console.log(this.state);
  };

  addTableRows = ()=>{ 
    const rowsInput={ 
        project_name:'',
        duration:'',
        role:''  ,
        languages:'',
    } 
    
    this.setState({ 
      rowsData :([...this.state.rowsData, rowsInput])
    });
  
  }

  handleChange = (index, evnt)=>{
  
    const { name, value } = evnt.target;
    const rowsInput = [...this.state.rowsData];
    rowsInput[index][name] = value;
    this.setState({ 
      rowsData: (rowsInput)
    });
    // console.log(this.state.rowsData);
  }

  deleteTableRows = (index)=>{
    const rows = [...this.state.rowsData  ];
    console.log("Going to Delete: ", index)
    rows.splice(index+1,1);
    this.setState({
    rowsData :(rows)
   }); 
    // console.log("delete",this.state.rowsData);
  
  }

  handleShowModal = () => { 
    this.setState(prevState => ({ showHide: !prevState.showHide })) 
  }
    
  render() {
    return (
        <div id="profile-section"> 
       <Container>
        <div className="userInfo-section">
          <h2 className='content-head'><span>Complete Your Profile</span></h2>
        <Form onSubmit={this.submitHandler}> 
       {/*  Personal Information  */} 
       <h3 className="main-heading">
        <span className='icon-head personal-info-icon'><BsFillPersonPlusFill /></span>Personal Information</h3>  
        <Row className='input-section'> 
          <Col> 
              <Form.Label htmlFor="name">Name <span className='important'>*</span></Form.Label>
              <Form.Control type="text" name='name' value="Abnit Chauhan" disabled /> 
          </Col> 
          <Col>
              <Form.Label htmlFor="employee_id">Employee ID <span className='important'>*</span></Form.Label>
              <Form.Control type="text" name='employee_id' value="31133" disabled /> 
          </Col>
          <Col>
              <Form.Label htmlFor="grade">Grade <span className='important'>*</span></Form.Label>
              <Form.Control type="text" name='grade' value="E" disabled /> 
          </Col>
          <Col>
              <Form.Label htmlFor="experience">Email <span className='important'>*</span></Form.Label>
              <Form.Control type="text" name='email' value="abnit.c@tataelxsi.co.in"disabled  /> 
          </Col> 
        </Row>
        {/* Personal Information Ends */}

        {/* Professional Information */} 

        <h3 className='main-heading'>
           <span className='icon-head professional-icon'><BsFillPersonLinesFill /></span>
           Professional Information</h3> 
        {/* Primary Skills */}
        <Row className='input-section'> 
        <div className="with-add-items">
          <Form.Label htmlFor="primary_skills">Primary Skills</Form.Label> 
          <Button variant='success' size='sm' onClick={this.displaySkills}><BsPlusCircleFill /> Add</Button>
        </div>
          <Col md={12}>
          <Table striped bordered hover>
          <thead>
            <tr>
              <th>Skill</th>
              <th>Trained</th>
              <th>Beginner</th>
              <th>Intermediate</th>
              <th>Expert</th>
            </tr>  
          </thead>
            <tbody>
               
               {this.state.primary_skill.map((primarySkill:any,index) => {
                  return (
                    <tr key={index}>
                    <td>
                      <Dropdown skills={this.all_skills} />
                      {/* <Form.Control as="Select" aria-label='skill' name="skill">
                         {this.all_skills.map((skill, index) =>{
                          return(<option value={index}>{skill}</option>)
                         })}
                      </Form.Control> */}
                    </td> 
                    { this.proficiencies.map((proficiency,idx ) => { 
                      return(<td><Form.Check type="radio" name={`proficiency_${index}`} id={`trained_${idx}`}  value={proficiency} onChange={this.addPrimarySkills}/></td>)
                    })} 
                  </tr>
                   ) })}   
          </tbody>
          </Table>
          </Col> 
        </Row> 
        {/* Primary Skills Ends */}

        {/* Other Skills */}
        <Row className='input-section'> 
        <Form.Group>
          <Form.Label htmlFor="otherSkills"> Other Skills </Form.Label>
          <Form.Control as="textarea" name="otherSkills" id="otherSkills" cols={30} rows={3}></Form.Control>
        </Form.Group> 
        </Row>
        {/* Other Skills Ends */}
        
   {/* Professional Summary */} 
   <Row className='input-section'>
     <div className="with-add-items">
     <Form.Label htmlFor="professional_summary">Professional Summary</Form.Label> 
          <Button variant='success' size='sm' 
           onClick={this.addTableRows}
          // onClick={() => setNoOfRows(noOfRows + 1)}
          >
            <BsPlusCircleFill /> Add</Button>
        </div>
          <Col md={12}>
              <Table striped bordered hover>
                <thead>
                <tr>
                  <th>Project Name</th>
                  <th>Duration</th>
                  <th>Roles &amp; Responsibilities</th>
                  <th>Skills/Languages</th>
                  <th>Action</th>
                </tr>         
                </thead>
                  {/* {this.state.onAdded === true ? */}
                <tbody>
                {this.state.rowsData.map((data, index)=>{

                    const {project_name, duration, role,languages}= data;
           
                  return(
                <tr key={index}>
                  
                  <td><Form.Control name="project_name" type='text' value ={project_name} onChange={(evnt)=>(this.handleChange(index, evnt))}/>
                  </td>
                  <td><Form.Control name="duration" type='text' value ={duration} onChange={(evnt)=>(this.handleChange(index, evnt))}
                  /></td>
                  <td><Form.Control name="role" type='text' value={role}
                  onChange={(evnt)=>(this.handleChange(index, evnt))}
                  /></td> 
                  <td><Form.Control as='textarea' name="languages" value={languages}
                  onChange={(evnt)=>(this.handleChange(index, evnt))}
                  rows={1} /></td> 
                  <td>
                    {data[0]?<Button type="button" variant='primary' size='sm' className="addbutton" onClick={this.addTableRows} >
                      {/* <BsFillPencilFill /> */}
                      <AiOutlinePlus />
                      </Button>:<Button type="button" variant='danger' size='sm' className="deleteBtn" onClick={this.deleteTableRows} >
                      {/* <BsFillPencilFill /> */}
                      <AiOutlineMinus />
                      </Button>} 
                  </td>
                </tr> 
                  )
                })}
                </tbody>
                 {/* : null } */}
              </Table>
          </Col>
      </Row>
        {/* Professional Summary Ends */}
        {/* Certifications*/}
        <Row className='input-section'>
        <Form.Group>
          <Form.Label htmlFor="certifications">  Certifications </Form.Label>
          <Form.Control as="textarea" name="certifications" id="certifications" cols={30} rows={3}></Form.Control>
        </Form.Group> 
        </Row>
        {/* Other Certifications Ends */}

        {/* Trainings */}
       <Row className='input-section'>
        <Form.Group>
          <Form.Label htmlFor="trainings">  Trainings </Form.Label>
          <Form.Control as="textarea" name="trainings" id="trainings" cols={30} rows={3}></Form.Control>
        </Form.Group> 
        </Row>
        {/* Trainings Ends */}
        
      {/* Professional Information Ends */}
      
      {/* Update Button */} 
        <div className="text-end mb-3 mt-3">
          <Button type='submit' id="submit-btn"  variant='primary' onClick={this.handleShowModal}>Update</Button>
        </div>

        {/* Update Button Ends  */}   
        </Form> 
        </div>

        <Modal

 show={this.state.showHide}

 onHide={this.handleShowModal}

size="md"

aria-labelledby="contained-modal-title-vcenter"

centered

>



<Modal.Body>



  <div className="heading">AWESOME!</div>

  {/* <TiTickOutline className='iconStyle' /> */}

 

  <p style={{justifyContent:"center",color:"green",textAlign:"center"}}>

   You have Succesfully updated your Profile!

  </p>

</Modal.Body>



<div  className='buttonContainer' >

  <Button variant="primary" onClick={this.handleShowModal} className="closeButton">Close</Button>

  </div>



</Modal>

      </Container> 
      </div>
    )
  }
}
