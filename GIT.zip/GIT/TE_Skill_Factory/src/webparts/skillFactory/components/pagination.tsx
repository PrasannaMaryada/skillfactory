import * as React from 'react';
import Button from 'react-bootstrap/Button';
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

export default class Pagination extends React.Component<{increase:any, decrease:any, skip:any,datalen:any,statusData:any,firstPage:any}> {
 
  state = {
   // data: statusData,
    showHide: false,
    status: '',
    selectedId: 1,
    change: false,
    rowsPerPage: 10,
    page: 1
  }
 render() {
    const {increase, decrease, skip, datalen,statusData,firstPage}=this.props
    const { rowsPerPage, page } = this.state
    // const endOffSet = Math.min(statusData.length, rowsPerPage * page)
    // const tableData = statusData.slice((page - 1) * rowsPerPage, endOffSet)
return (
      <div className= "pagination-button-group">
      <Container fluid={true}  >
        <Row >
          <Col sm={12}>
            <div className= "pagination-button-group">
                    <Button
                      size="sm"
                      style={{ marginLeft: '12px' }}
                      variant="outline-info"
                      disabled={page <= 1}
                      onClick={() => {this.setState({ page: 1 });firstPage()}}>
                      {`<<`}
                    </Button>
                    <Button
                      size="sm"
                      style={{ marginLeft: '12px' }}
                      variant="outline-info"
                      disabled={page <= 1}
                      onClick={() =>{ this.setState({ page: page - 1 });decrease()}}>
                      {`<`}
                    </Button>
                    <span style={{ marginLeft: '8px' }}>{page} </span>
                    <Button
                      size="sm"
                      style={{ marginLeft: '8px' }}
                      variant="outline-info"
                      disabled={(page * rowsPerPage) >= statusData.length}
                      onClick={() => {this.setState({ page: page + 1 });increase()}}>
                      {`>`}
                    </Button>
                    <Button
                      size="sm"
                      style={{ marginLeft: '12px' }}
                      variant="outline-info"
                      disabled={page >= Math.ceil(statusData.length / 10)}
                      onClick={() => {this.setState({ page: Math.ceil(datalen / 10) });skip()}}>
                      {`>>`}
                    </Button>
                  </div>
               </Col>
        </Row>
      </Container>
      </div>
      )
  }
}
