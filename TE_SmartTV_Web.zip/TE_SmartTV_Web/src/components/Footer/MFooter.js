import React from 'react'
import styles from './Mfooter.module.css'
import { useSelector } from 'react-redux'

const MFooter = () => {
  const {mfooterData} = useSelector((state) => ({
    mfooterData: state.MenuReducer?.toJS().data.mfooterData
  }))
 
  return (
    <div className={styles.mfooter}>
      <div className={styles.msub_menu_container}>
        {mfooterData && mfooterData.map && mfooterData?.map(item => {
            return (
              <div className={styles.micon_container}>
                <img key={item.menuL1Id} className={styles.micons} src={item.defaultImageIcon} alt='submenu...'/>
                <span className={styles.micon_title}>{item.menuL1Title}</span>
              </div>
            )
        })}
      </div>
    </div>
  )
}

export default MFooter