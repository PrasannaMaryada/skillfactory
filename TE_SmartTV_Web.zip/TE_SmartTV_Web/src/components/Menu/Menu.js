import React, { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { menuApi } from '../../actions/MenuAction';
import { store } from '../../Router';
import styles from './Menu.module.css'
import { layoutApi } from '../../actions/LayoutAction';
import { NavLink } from 'react-router-dom';

const Menu = () => {

    const {mainData, webSubMenuData} = useSelector((state) => ({
        mainData: state.MenuReducer?.toJS().data.mainData,
        webSubMenuData: state.MenuReducer?.toJS().data.webSubMenuData
    }))
    
    useEffect(() => {
        store.dispatch(menuApi())
    }, [])
    
    const onClickMenuItem = (item) => {
        store.dispatch(layoutApi(item.menuL1DeeplinkUrl));	
    }

    return (
        <>
            <div className={styles.main_menu_container}>
                {mainData && mainData.map && mainData?.map(item => {
                    return (
                        <NavLink 
                            to={`/${item.menuL1Title.toLowerCase().replace(/ /g, "")}`}
                            className={({ isActive }) => (isActive ? styles.l1_active : styles.l1_inactive)}
                        >
                            <div key={item.menuL1Id} className={`${styles.left_info}`} onClick={() => onClickMenuItem(item)}>
                                {item.menuL1Title}
                            </div>
                        </NavLink>
                    )
                })}
            </div>
            <div className={styles.sub_menu_container}>
                {webSubMenuData && webSubMenuData.map && webSubMenuData?.map(item => {
                    return (
                        <img key={item.menuL1Id} className={styles.right_info} src={item.defaultImageIcon} alt='submenu...'/>
                    )
                })}
            </div>
        </>
    )
}

export default Menu;