import React from 'react'

const BannerImages = (props) => {
    const { Styles, data } = props;

    return (
        <div
            className={Styles.carousel_item}>
            <img src={data} alt="img of carousel" />
        </div>
    )
}

export default BannerImages;