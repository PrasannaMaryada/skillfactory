import React, { useRef, useState, useEffect } from 'react'
import Styles from "./Banner.module.css";
import BannerImages from './BannerImages';

let autoScroll;
const Banner = ({ images }) => {
    let autoIndex = 1;
    const carousel = useRef();
    const [currentIndex, setCurrentIndex] = useState(0)

    const scrollHandler = () => {
        autoScroll = setInterval(() => {
            console.log("Interval ")
            if (autoIndex < images.length) {
                onRowFocus(autoIndex, '')
            }
            else {
                onRowFocus(0, '');
            }
        }, 3000)
    }
    const onRowFocus = (x, functionality) => {
        if (functionality === 'onClick') {
            clearInterval(autoScroll)
        }
        setCurrentIndex(x);
        autoIndex = x + 1;
        const width = carousel.current.offsetWidth;
        if (carousel.current.scrollTo) {
            carousel.current.scrollTo({
                left: width * x,
                behavior: 'smooth'
            })
            if (functionality === 'onClick') {
                scrollHandler()
            }
        } else {
            carousel.current.scrollLeft = x
        }
    }

    useEffect(() => {
        onRowFocus(0, '')  //when this component is reused, the images should comes from the start. so that onRowFocus is called  
        images.length && scrollHandler();
        return () => clearInterval(autoScroll)
    }, [images])

    return (
        <>
            <div className={Styles.carousel_container}>
                {<div className={Styles.carousel} ref={carousel}>
                    {images.length && images.map((data, index) => (
                        <BannerImages key={index} Styles={Styles} data={data} onRowFocus={onRowFocus} />
                    ))}
                </div>}
            </div>
            <div className={Styles.dot_container} >
                {images.length && images.map((img, index) => (
                    <div className={`${currentIndex === index ? Styles.dot_active : Styles.dot} ${images.length - 1 !== index && Styles.dot_margin}`} key={img + index} onClick={() => onRowFocus(index, 'onClick')}></div>
                ))}
            </div>
        </>
    );
};




export default Banner;
