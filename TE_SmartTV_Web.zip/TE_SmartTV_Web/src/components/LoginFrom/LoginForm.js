import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { path } from '../../constant/constants';
import { menuApi } from '../../actions/MenuAction';
import styles from './loginForm.module.css'
import { store } from '../../Router';

const LoginForm = () => {

  const { mainData } = useSelector((state) => ({
    mainData: state.MenuReducer?.toJS().data.mainData,
  }))

  const menuFirstItem = mainData[0]?.menuL1Title.toLowerCase().replace(/ /g, "")
  
  const navigate = useNavigate();
  const submitHandler = (e) => {
    e.preventDefault();
    navigate(`/${menuFirstItem}`);
  }

  useEffect(() => {
    store.dispatch(menuApi())
  }, [])

  return (
    <div className={styles.loginForm}>
      <form onSubmit={(e) => submitHandler(e)}>
        <h1>Login</h1>
        <div classNameclass={styles.content}>
          <div className={styles.inputField}>
            <input type="email" placeholder="Email" autocomplete="nope" />
          </div>
          <div className={styles.inputField}>
            <input type="password" placeholder="Password" autocomplete="new-password" />
          </div>
          <a href="#" className={styles.link}>Forgot Your Password?</a>
        </div>
        <div className={styles.action}>
          <button type='submit'>Log in</button>
          <button onClick={() => navigate(path.register)}>Not Have Account?</button>
        </div>
      </form>
    </div>
  )
}

export default LoginForm