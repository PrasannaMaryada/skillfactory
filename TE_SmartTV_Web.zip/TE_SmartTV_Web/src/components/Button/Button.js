import React from 'react'

const Button = () => {
    return (
        <div>Button</div>
    )
}

export default Button