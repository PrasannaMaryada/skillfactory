import React, { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { logoApi } from '../../actions/LogoAction';
import styles from './Logo.module.css'
import { store } from '../../Router';

const Logo = () => {

    const { logoData } = useSelector((state) => ({
        logoData: state.LogoReducer?.toJS().logoData
    }))

    useEffect(() => {
        store.dispatch(logoApi())
    }, [])
    
    return (
        <img className={styles.logo} src={logoData.imageurl?logoData.imageurl:'../assets/logo.png'}/>
    )
}

export default Logo;
