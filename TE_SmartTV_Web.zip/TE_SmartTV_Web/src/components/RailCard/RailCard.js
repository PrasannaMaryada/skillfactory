import React,{useEffect,useState,useRef} from 'react'
import styles from './railCard.module.css'
import { DEVICE_TYPE } from '../../constant/environment'

const PotraitCard = (props) => {
  return(
    props.data.map(item=>{
      const image=item.images.filter(image=>image.imagetype=='Potrait')[0]?.imageurl
      return(
        <div className={styles.potrait_card} key={item.name}>
          <img 
            className={styles.potrait_img} 
            src={image?image:item.images[0].imageurl}
            alt={item.name}
          />
        </div>
      )
    })
  )
}

const LandscapeCard = (props) => {
    const image=props.item.images.filter(image=>image.imagetype=='Landscape')[0]?.imageurl
    return(
      <div key={props.item.name} className={`${styles.landscape_card} ${DEVICE_TYPE=='smart_tv'&&styles.tv_landscape_card}`}>
        <img 
          className={styles.landscape_img} 
          src={image?image:props.item.images[0].imageurl}
          alt={props.item.name}
        />
        {/* <div className={styles.landscape_card_info}>
          <p className={styles.landscape_card_title}>{props.item.name}</p>
          <p className={styles.landscape_card_genre}>Thriller | 2 Seasons</p>
        </div> */}
      </div>
    )
}

const AppsCard=(props)=>{
  return(
    props.data.map(item=>{
      const image=item.images.filter(image=>image.imagetype=='Landscape')[0]?.imageurl
      return(
        <div className={styles.app_card} key={item.name}>
          <img 
            className={styles.app_img} 
            src={image?image:item.images[0].imageurl}
            alt={item.name}
          />
        </div>
      )
    })
  )
}

const ChannelCard = (props)=>{
  return(
    props.data.map(item=>{
      const image=item.images.filter(image=>image.imagetype=='Landscape')[0]?.imageurl
      return(
        <div className={styles.channel_card} key={item.name}>
          <p className={styles.lcn_number}>{item.lcn.toString().padStart(4, '0')}</p>
          <img 
            className={styles.channel_img} 
            src={image?image:item.images[0].imageurl}
            alt={item.name}
          />
        </div>
      )
    })
  )
}

const DeadAsset=(props)=>{
  return(
    props.data.map(item=>{
      return(
        <div className={styles.dead_card} key={item.name}>
          <img 
            className={styles.dead_img} 
            src={item.images[0].imageurl}
            alt='cardimg'
          />
        </div>
      )
    })
  )
}

const RailCard = (props) => {
  const[leftArrow,setLeftArrow] = useState(0)
  const[clientWidth,setClientWidth] = useState(0)
  const[scrollWidth,setScrollWidth] = useState(0)
  const[scrollVal,setScrollVal] = useState(0)
  const [showArrow,setShowArrow] = useState(false)
  const railref = useRef()

  const Layout = () => {
    if(props.asset_type=='Channel'){
      return <ChannelCard data={props.data}/>
    }
    if(props.asset_type=='Genre'||props.asset_type=='App'){
      return <AppsCard data={props.data}/>
    }
    if(props.asset_type=='Deadasset'){
      return <DeadAsset data={props.data}/>
    }
    if(props.layout==='Portrait'){
      return <PotraitCard data={props.data}/>
    }
    if(props.layout==='Landscape'){
      return (
          props.data?.map(item=><LandscapeCard item={item}/>)
      )
    }
  }

  const slideLeft=()=>{
    let container = document.getElementById(props.id);
    let scrollCompleted = 0;
    let slideVar = setInterval(function () {
        container.scrollLeft -= scrollVal;
        scrollCompleted += 10;
        if (scrollCompleted >= 100) {
            window.clearInterval(slideVar);
            setLeftArrow(container.scrollLeft)
        }
    }, 50);
  }

  const slideRight=()=>{
    let container = document.getElementById(props.id);
    let scrollCompleted = 0;
    let slideVar = setInterval(function () {
      container.scrollLeft += scrollVal;
      scrollCompleted += 10;
      if (scrollCompleted >= 100) {
          window.clearInterval(slideVar);
          setLeftArrow(container.scrollLeft)
      }
    }, 50);
  }

  const Dimensions = () =>{
    const newScrollWidth =  railref.current.scrollWidth
    const newClientWidth = railref.current.clientWidth
    setScrollWidth(newScrollWidth)
    setClientWidth(newClientWidth)
    setScrollVal(80)
  }

  useEffect(()=>{
    let container = document.getElementById(props.id);
    container.scrollLeft=0;
    setLeftArrow(0)
    window.scrollTo(0,0)
    if(DEVICE_TYPE=='web'){
      Dimensions()
    }
    window.addEventListener('resize',Dimensions )
    return () => { window.removeEventListener('resize',Dimensions) }
  },[props.id])

  return (
    <>
     {(props.asset_type!='Deadasset' && props.asset_type!='Genre') && <h1 className={styles.category}>{props.category}</h1>}
      <div className={styles.card_container} key={props.id}
        onMouseEnter={()=>setShowArrow(true)} 
        onMouseLeave={()=>setShowArrow(false)} 
      >
        {leftArrow!=0 && showArrow &&
          <div 
            className={`${props.layout==='Landscape'&&styles.landscape_left_arrow_container} 
            ${props.layout==='Portrait'&&styles.potrait_left_arrow_container}
            ${(props.asset_type=='Channel'||props.asset_type=='Genre'||props.asset_type=='App')&&styles.card_left_arrow_container}`} 
            onClick={slideLeft}
          >
            <img 
              src='../assets/left_arrow.png' 
              className={`${styles.arrow}`} 
              alt='left-arrow'
            />
          </div> 
        }
        {DEVICE_TYPE === 'web' ? 
          <div ref={railref} id={props.id} className={styles.slider}>
              {Layout()}
          </div>:
          <div  id={props.id} className={styles.slider}>
              {Layout()}
          </div>
        }
        {scrollWidth > Math.ceil(clientWidth + leftArrow)&& showArrow &&
          <div 
            className={`${props.layout==='Landscape'&&styles.landscape_right_arrow_container} 
            ${props.layout==='Portrait'&&styles.potrait_right_arrow_container}
            ${(props.asset_type=='Channel'||props.asset_type=='Genre'||props.asset_type=='App')&&styles.card_right_arrow_container}`} 
            onClick={slideRight}
          >
            <img src='../assets/right_arrow.png' 
              className={styles.arrow} 
              alt='right-arrow' 
            />
          </div>
        }
      </div>
    </>
  )
}

export default RailCard