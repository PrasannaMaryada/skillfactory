export const Data = [
    {
        id:1,
        title:'Kapil Sharma',
        rail_display_type:'Landscape',
        imageUrl:"https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/A804xKHS1D5k3Fc1596276418_gv.png",
        potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/NwCjWlFu5HZ0OnC1596276450_gv.png'
    },
    {
        id:2,
        title:'Spider man',
        rail_display_type:'Landscape',
        imageUrl:"https://adtvraw.blob.core.windows.net/images/imgstore/2022g/7g/9g/fYBPGiPHn567kpJ1657348984_gv.jpg",
        potrait:'https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/n79r5KOl9zFkUDx1648632228_gv.png'
    },
    {
        id:3,
        title:'Chernobyl',
        rail_display_type:'Landscape',
        imageUrl:"https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/9yCqADyJzbvJfqB1596276326_gv.png",
        potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/7mKENT2M6le712v1596276367_gv.png'
    },
    {
        id:4,
        title:'Money Heist',
        rail_display_type:'Landscape',
        imageUrl:"https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/d895EHLiNBs8DvO1648632217_gv.png",
        potrait:'https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/DILBjgdYPWpgYPB1648631989_gv.png'
    },
    {
        id:5,
        title:'Game of Thrones',
        rail_display_type:'Landscape',
        imageUrl:"https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/TltRKN2lFlrGdlm1648631973_gv.png",
        potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/6g/30g/x7878ybKWiuYtEa1596099204_gv.png'
    },
    {
        id:6,
        title:'Game of Thrones',
        rail_display_type:'Landscape',
        imageUrl:"https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/TltRKN2lFlrGdlm1648631973_gv.png",
        potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/6g/30g/aBWvXmTymOX8WVe1596093707_gv.png'
    },
    {
      id:7,
      title:'Spider man',
      rail_display_type:'Landscape',
      imageUrl:"https://adtvraw.blob.core.windows.net/images/imgstore/2022g/7g/9g/fYBPGiPHn567kpJ1657348984_gv.jpg",
      potrait:'https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/n79r5KOl9zFkUDx1648632228_gv.png'
  },
  {
      id:8,
      title:'Chernobyl',
      rail_display_type:'Landscape',
      imageUrl:"https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/9yCqADyJzbvJfqB1596276326_gv.png",
      potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/7mKENT2M6le712v1596276367_gv.png'
  },
    {
        id:9,
        title:'Game of Thrones',
        rail_display_type:'Landscape',
        imageUrl:"https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/TltRKN2lFlrGdlm1648631973_gv.png",
        potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/6g/30g/x7878ybKWiuYtEa1596099204_gv.png'
    },
    {
        id:10,
        title:'Game of Thrones',
        rail_display_type:'Landscape',
        imageUrl:"https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/TltRKN2lFlrGdlm1648631973_gv.png",
        potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/6g/30g/aBWvXmTymOX8WVe1596093707_gv.png'
    },
    {
      id:11,
      title:'Spider man',
      rail_display_type:'Landscape',
      imageUrl:"https://adtvraw.blob.core.windows.net/images/imgstore/2022g/7g/9g/fYBPGiPHn567kpJ1657348984_gv.jpg",
      potrait:'https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/n79r5KOl9zFkUDx1648632228_gv.png'
  },
  {
      id:12,
      title:'Chernobyl',
      rail_display_type:'Landscape',
      imageUrl:"https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/9yCqADyJzbvJfqB1596276326_gv.png",
      potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/7mKENT2M6le712v1596276367_gv.png'
  },
  {
    id:13,
    title:'Kapil Sharma',
    rail_display_type:'Landscape',
    imageUrl:"https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/A804xKHS1D5k3Fc1596276418_gv.png",
    potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/NwCjWlFu5HZ0OnC1596276450_gv.png'
},
{
    id:14,
    title:'Spider man',
    rail_display_type:'Landscape',
    imageUrl:"https://adtvraw.blob.core.windows.net/images/imgstore/2022g/7g/9g/fYBPGiPHn567kpJ1657348984_gv.jpg",
    potrait:'https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/n79r5KOl9zFkUDx1648632228_gv.png'
},
{
    id:15,
    title:'Chernobyl',
    rail_display_type:'Landscape',
    imageUrl:"https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/9yCqADyJzbvJfqB1596276326_gv.png",
    potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/7g/1g/7mKENT2M6le712v1596276367_gv.png'
},
{
    id:16,
    title:'Money Heist',
    rail_display_type:'Landscape',
    imageUrl:"https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/d895EHLiNBs8DvO1648632217_gv.png",
    potrait:'https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/DILBjgdYPWpgYPB1648631989_gv.png'
},
{
    id:17,
    title:'Game of Thrones',
    rail_display_type:'Landscape',
    imageUrl:"https://teplaycms.blob.core.windows.net/teplaycms/imgstore/2022g/3g/30g/TltRKN2lFlrGdlm1648631973_gv.png",
    potrait:'https://teplaycms.blob.core.windows.net/teplayclient/imgstore/2020g/6g/30g/x7878ybKWiuYtEa1596099204_gv.png'
},
] 