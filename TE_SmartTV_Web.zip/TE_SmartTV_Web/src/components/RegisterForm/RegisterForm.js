import React from 'react'
import { useNavigate } from 'react-router-dom'
import { path } from '../../constant/constants';
import styles from './registerForm.module.css'

const RegisterForm = () => {

    const navigate = useNavigate();
    const submitHandler = (e) => {
        e.preventDefault();
        navigate(path.home);
      }

    return (
        <div className={styles.loginForm}>
            <form onSubmit={(e) => submitHandler(e)}>
                <h1>Register</h1>
                <div classNameclass={styles.content}>
                    <div className={styles.inputField}>
                        <input type="text" placeholder="Username" autocomplete="nope" />
                    </div>
                    <div className={styles.inputField}>
                        <input type="email" placeholder="Email" autocomplete="nope" />
                    </div>
                    <div className={styles.inputField}>
                        <input type="password" placeholder="Password" autocomplete="new-password" />
                    </div>
                    <a href="#" className={styles.link}>Forgot Your Password?</a>
                </div>
                <div className={styles.action}>
                    <button type='submit'>Register</button>
                    <button onClick={() =>navigate(path.login)}>Have Account?</button>
                </div>
            </form>
        </div>
    )
}

export default RegisterForm