import { routerMiddleware } from 'react-router-redux';
import { applyMiddleware, compose, legacy_createStore as createStore } from 'redux';
import createSagaMiddleware from 'redux-saga';
import rootReducer from '../reducers/index';
import BannerSaga from '../saga/BannerSaga';
import LogoSaga from '../saga/LogoSaga';
import MenuSaga from '../saga/MenuSaga';
import RailSaga from '../saga/RailSaga';
import LayoutSaga from '../saga/LayoutSaga';

const sagaMiddleware = createSagaMiddleware();

function configureStore(initialState, history) {
    const middlewares = [sagaMiddleware, routerMiddleware(history)];
    const composeEnhancers = compose;

    const store = createStore(
        rootReducer(),
        initialState,
        composeEnhancers(applyMiddleware(...middlewares))
    );

    sagaMiddleware.run(BannerSaga);
    sagaMiddleware.run(LogoSaga);
    sagaMiddleware.run(MenuSaga);
    sagaMiddleware.run(RailSaga);
    sagaMiddleware.run(LayoutSaga);

    store.runSaga = sagaMiddleware.run;
    store.asyncReducer = {};
    return store;
}


export default configureStore;

