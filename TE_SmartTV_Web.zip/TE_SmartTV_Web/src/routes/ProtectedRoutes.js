import React from "react";
import {Navigate, Outlet} from "react-router-dom";

const useAuth = () => {
	//get item from localstorage
	// const user = localStorage.getItem("token")
	const user=true;

	if (user) {
		return {
			auth: true
		}
	} else {
		return {
			auth: false
		}
	}
}

const ProtectedRoutes = (props) => {
	const {auth} = useAuth()

	return auth ? <Outlet /> : <Navigate replace to="/" />
	
}

export default ProtectedRoutes;
