import React from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import FormLayout from '../containers/FormLayout/FormLayout';
import PublicRoutes from './PublicRoutes';
import ProtectedRoutes from './ProtectedRoutes';
import Layout from '../containers/Layout/Layout';
import { path } from '../constant/constants'

const RouteList = () => {
    return (
        <Routes>
            <Route element={<ProtectedRoutes />}>
                <Route exact path="/:name" element={<Layout screen={path.home} />} />
                <Route exact path="/" element={<Layout screen={path.home} />} />
                <Route exact path={path.settings} element={<Layout screen={path.settings} />} />
            </Route>
            <Route element={<PublicRoutes />}>
                <Route exact path={path.login} element={<FormLayout screen={path.login} />} />
                <Route exact path={path.register} element={<FormLayout screen={path.register} />} />
            </Route>
        </Routes>
    )
}

export default RouteList;