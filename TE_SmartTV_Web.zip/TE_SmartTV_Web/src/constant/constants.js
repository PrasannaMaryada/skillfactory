export const path = {
    home: "/home",
    movies: "/movies",
    shows: "/shows",
    settings: "/settings",
    login: "/login",
    register: "/register",
    rail: "/rail",
    mytv:"/mytv",
    live:'/live',
    apps:'/apps'
}