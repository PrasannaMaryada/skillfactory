export const BASE_URL = {
    SERVER_CMS: "https://tecmsc.teplay.co",
    SERVER_SMS: 'https://tesmsc.teplay.co',
    VERSION1: '/v1',
    VERSION2: '/v2'
}

export const URL = {
    BANNER_URL: BASE_URL.VERSION1+"/banners?layout_id=5eb8de2bc719b03c6ee63aa1&parental_rating=ALL&profileid=10000000001171&subscriberid=118&devicetype=androidtv",
    LOGO_URL: BASE_URL.VERSION1+"/logo",
    MENU_URL: BASE_URL.VERSION1+"/menu?lang_code=en&devicetype=androidtv",
    RAIL_URL: BASE_URL.VERSION2+"/rails",
    LAYOUT_URL: BASE_URL.VERSION1
    //sms urls
    //cms urls
};

export const DEVICE_TYPE = "web"; // ? "smart_tv"
// export const DEVICE_TYPE = "smart_tv";