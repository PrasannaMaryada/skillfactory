// TODO: both web and smart tv
import React, { useState } from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter as WebRouter } from 'react-router-dom';
import RouteList from './routes/RouteList';
import configureStore from './store/configureStore';
import "./constant/colors.css"

export const store = configureStore({}, window.history);

const Router = () => {
    const [isLoggedin, setIsLoggedIn] = useState(localStorage.getItem('token') ? true : false)

    return (
        <Provider store={store}>
            <WebRouter>
                <RouteList />
            </WebRouter>
        </Provider>
    )
}

export default Router
