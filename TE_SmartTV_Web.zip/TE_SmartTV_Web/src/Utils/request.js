import 'whatwg-fetch';
import 'isomorphic-fetch';
import { store } from '../Router';
import { BASE_URL, URL } from '../constant/environment';
// import { refreshToken } from '../routes/Login/LoginActions';

// Global handling for each specific response status code can be directly written under each case.
const GLOBAL_RESPONSE_STATUS_CODE_HANDLERS = {
    // Unauthorized
    401: () => {
        localStorage.removeItem('token');
        window.location.reload()
        return false;
    },
    503: () => false,
    500: async (e, action) => {
        if (e.exception === "io.jsonwebtoken.ExpiredJwtException") {
            // await store.dispatch(refreshToken());
            setTimeout(() => {
                store.dispatch({ type: `${action.type}`, payload: (action.body || action.payload) })
            }, 2000);
        }
    },
};

// const redirectToLoginPage = () => {
//   localStorage.removeItem('authToken');
// };

export function get(url) {
    return api(url, 'GET');
}

export function post(url, payload) {
    return api(url, 'POST', payload);
}

function checkStatus(response) {
    if (response.status !== 503) {
        return response;
    }
    const error = new Error(response.statusText);
    error.response = response;
    throw error;
}

/**
 *
 * @param url
 * @param options
 * @param callback
 * @param tokenRequired
 * @returns {Function}
 */

export default function request(url, options, callback, tokenRequired = true, action) {
    if ((tokenRequired && (localStorage.getItem('authToken') || localStorage.getItem('accessToken'))) || !tokenRequired) {
        options.body = typeof options.body !== 'string' ? JSON.stringify(options.body) : options.body;
        const defaultHeaders = {
            Accept: 'application/json',
            'Content-Type': 'application/json',
        };
        if (tokenRequired) {
            let CMSLOGIN = false;
            let SMSLOGIN = false;
            // if(url.includes(BASE_URL.SERVER_CMS)) { CMSLOGIN = true };
            // if(url.includes(BASE_URL.SERVER_SMS)) { SMSLOGIN = true };
            if (url.includes(BASE_URL.SERVER_CMS) && !url.includes(URL.DRMTOKEN_URL)) { CMSLOGIN = true };
            if (url.includes(BASE_URL.SERVER_SMS) || url.includes(URL.DRMTOKEN_URL)) { SMSLOGIN = true };
            options.headers = (url === "/rest/user/authToken") ?
                {
                    RefreshToken: localStorage.getItem('refreshToken')
                } :
                {
                    Authorization: SMSLOGIN ? (localStorage.getItem('token') ? 'Bearer ' + localStorage.getItem('token') : '') : 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzUxMiJ9.eyJleHAiOjE2NjM3NjQyMjAsInVzZXJuYW1lIjoidGF0YSIsInRva2VuX3R5cGUiOiJhY2Nlc3MiLCJpZCI6IjYwMThlMGZjNDIzOTg0NTY4ODFmNTJiOCIsImlzc3VwZXJ1c2VyIjoxLCJpYXQiOjE2NjM2Nzc4MjB9.KF_jnsuI-qzZj1Zvyb1PVkOsKSdE_AQ4O-RLD2eoOnupUFB2HGZcN6c77sT-7eW0kU-bQkzGLqxo693F22pDZ3undp8MKGZAWNADvy0GbtpGho8hn9lpHz3TLG34umfsnspLyhtuhMU-HYeUhtZUMuBmltHBzgkISJ8ygPGGR4k17HaharLPmZTRWGli8BR_Jq5AcWMpAitYnEMgdGQ4qXMulbkC1faK6n81T58CDViRoV_x6l4UkwGXuh8MiLb89-0J7ukTifTULqVcedemZ4p8mHFEkf3I2HIkzzxn75Lr3QEh9V1w7VhVJjvH6M0743oLU1P9_kiSg9_c1_uQfA' /* + localStorage.getItem('accessToken') */
                }
        }
        options.headers = options.headers
            ? Object.assign({}, defaultHeaders, options.headers)
            : defaultHeaders;
        let statusCode,
            responseStatus,
            responseStatusCode;
        return fetch(url, {
            credentials: 'same-origin',
            ...options,
        })
            .then(checkStatus)
            .then((response) => {
                response.headers.get('authorization') !== null && localStorage.setItem('authToken', response.headers.get('authorization'));
                response.headers.get('refreshtoken') !== null && localStorage.setItem('refreshToken', response.headers.get('RefreshToken'));
                statusCode = response.status;
                /*if (statusCode === 401) {
                  redirectToLoginPage();
                  return;
                }*/
                responseStatus = statusCode >= 200 && statusCode < 300 ? 'onSuccess' : 'onError';
                responseStatusCode = statusCode.toString();
                return response.json();
            })
            .then((resp) => {
                if (responseStatus in callback) {
                    callback[responseStatus](resp);
                }
                if (responseStatusCode in GLOBAL_RESPONSE_STATUS_CODE_HANDLERS) {
                    GLOBAL_RESPONSE_STATUS_CODE_HANDLERS[responseStatusCode](resp, action);
                }
                // Custom handling for each specific response status code is done based on whether
                // the specific response code keys are present in the callback object or not.
                if (responseStatusCode in callback) {
                    callback[responseStatusCode](resp);
                }
                return resp;
            });
    }
}


/**
 * For 502 we will not get JSON response, hence throw error
 * @param response
 * @returns {*}
 */



// WEBPACK FOOTER //
// ./src/utils/request.js