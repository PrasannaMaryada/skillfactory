import React from "react";
import styles from "./home.module.css";
import { useSelector } from "react-redux";
import RailCard from "../../components/RailCard/RailCard";
import Banner from "../../components/Banner/Banner";

const Home = () => {
  const {bannerData,railsData} = useSelector((state)=>({
    bannerData:state.RailReducer?.toJS().data.bannerData,
    railsData:state.RailReducer?.toJS().data.railsData
  }))
  
  return (
    <>
      {bannerData&&<Banner images={bannerData}/>}
      <div className={styles.container}>
        {railsData&&railsData.map&&railsData.map(rail => (
            <RailCard
              asset_type={rail.existing_asset_type}
              layout={rail.rail_display_type}
              id={rail.rail_id}
              category={rail.name}
              data={rail.existing_asset.existing_asset}
            />
          ))
        }
      </div>
    </>
  );
};

export default Home;
