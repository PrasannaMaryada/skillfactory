import React from 'react'
import LoginForm from '../../components/LoginFrom/LoginForm'
import RegisterForm from '../../components/RegisterForm/RegisterForm';
import { path } from '../../constant/constants';

const FormLayout = (props) => {

  let screen = props.screen;

  switch (screen) {
    case path.login:
        screen = <LoginForm />;
        break;
    case path.register:
        screen = <RegisterForm />;
        break;
}

  return (
    <>
    {screen}
    </>
  )
}

export default FormLayout