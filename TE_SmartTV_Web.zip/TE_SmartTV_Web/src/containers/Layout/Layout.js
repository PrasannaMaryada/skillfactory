import React, { useEffect } from 'react';
import Header from '../../components/Header/Header';
import { path } from '../../constant/constants';
import Home from '../../pages/Home/Home';
import Settings from '../../pages/Settings/Settings';
import { store } from '../../Router';
import { useSelector } from 'react-redux';
import { layoutApi } from "../../actions/LayoutAction";
import MFooter from '../../components/Footer/MFooter';

const Layout = (props) => {
    let screen = props.screen;

    const { menuL1DeepLinkData } = useSelector((state) => ({
        menuL1DeepLinkData: state.MenuReducer?.toJS().data.menuL1DeepLinkData,
    }))

    useEffect(() => {
        if (menuL1DeepLinkData != undefined) {
            store.dispatch(layoutApi(menuL1DeepLinkData));
        }
    }, [menuL1DeepLinkData]);

    switch (screen) {
        case path.home:
            screen = <Home />;
            break;
        case path.settings:
            screen = <Settings />;
            break;
        default:
            break;
    }
    return (
        <>
            <div>
                <Header />
                {screen}
                <MFooter />
            </div>
        </>
    )
}

export default Layout;