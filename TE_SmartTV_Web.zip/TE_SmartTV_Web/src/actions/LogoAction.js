import { LOGO_CONTENT, LOGO_SUCCESS, LOGO_ERROR } from "./Constants.js";


export function logoApi(payload) {
    return { type: LOGO_CONTENT, payload}
}
export function logoApiSuccess(payload) {
    return { type: LOGO_SUCCESS, payload}
}
export function logoApiError(payload) {
    return { type: LOGO_ERROR, payload}
}