import { MENU_CONTENT, MENU_SUCCESS, MENU_ERROR } from "./Constants.js";


export function menuApi(payload) {
    return { type: MENU_CONTENT, payload}
}
export function menuApiSuccess(payload) {
    return { type: MENU_SUCCESS, payload}
}
export function menuApiError(payload) {
    return { type: MENU_ERROR, payload}
}