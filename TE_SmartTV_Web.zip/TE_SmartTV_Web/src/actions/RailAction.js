import { RAIL_CONTENT, RAIL_SUCCESS, RAIL_ERROR } from "./Constants.js";


export function railApi(payload) {
    return { type: RAIL_CONTENT, payload}
}
export function railApiSuccess(payload) {
    return { type: RAIL_SUCCESS, payload}
}
export function railApiError(payload) {
    return { type: RAIL_ERROR, payload}
}