import { LAYOUT_CONTENT, LAYOUT_SUCCESS, LAYOUT_ERROR } from "./Constants.js";


export function layoutApi(payload) {
    return { type: LAYOUT_CONTENT, payload}
}
export function layoutApiSuccess(payload) {
    return { type: LAYOUT_SUCCESS, payload}
}
export function layoutApiError(payload) {
    return { type: LAYOUT_ERROR, payload}
}