export const BANNER_CONTENT = "BANNER_CONTENT";
export const BANNER_SUCCESS = "BANNER_SUCCESS";
export const BANNER_ERROR = "BANNER_ERROR";

export const LOGO_CONTENT = "LOGO_CONTENT";
export const LOGO_SUCCESS = "LOGO_SUCCESS";
export const LOGO_ERROR = "LOGO_ERROR";

export const MENU_CONTENT = "MENU_CONTENT";
export const MENU_SUCCESS = "MENU_SUCCESS";
export const MENU_ERROR = "MENU_ERROR";

export const RAIL_CONTENT = "RAIL_CONTENT";
export const RAIL_SUCCESS = "RAIL_SUCCESS";
export const RAIL_ERROR = "RAIL_ERROR";

export const LAYOUT_CONTENT = "LAYOUT_CONTENT";
export const LAYOUT_SUCCESS = "LAYOUT_SUCCESS";
export const LAYOUT_ERROR = "LAYOUT_ERROR";