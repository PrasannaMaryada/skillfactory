import { BANNER_CONTENT, BANNER_SUCCESS, BANNER_ERROR } from "./Constants.js";


export function bannerApi(payload) {
    return { type: BANNER_CONTENT, payload}
}
export function bannerApiSuccess(payload) {
    return { type: BANNER_SUCCESS, payload}
}
export function bannerApiError(payload) {
    return { type: BANNER_ERROR, payload}
}