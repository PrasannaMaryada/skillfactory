import { fromJS } from 'immutable';
import * as constants  from '../actions/Constants.js';
import { createReducerFromObject } from '../Utils/reducerUtils';

export const initialState = fromJS({
    data:{
        mainData:{},
        tvSubMenu:{},
        webSubMenuData:{},
        menuL1DeepLinkData:{},
        mfooterData:{},
    },   
});

const reducerFunctions = {
    [constants.MENU_SUCCESS]: (state, payload) => {
        let mainMenu = payload?.filter(menu => menu.menuGroupId === "mainmenu")[0].menuL1
        let tvSubMenu = payload?.filter(menu => menu.menuGroupId === "submenu")[0].menuL1
        let webSubMenu = payload?.filter(menu => menu.menuGroupId === "submenu")[0].menuL1.filter(item=>item.menuL1Title=="Search"||item.menuL1Title=="Settings"||item.menuL1Title==="Profile")
        let mfooterMenu = [...webSubMenu]
        mfooterMenu.unshift({"defaultImageIcon":'../assets/home.png',"menuL1Title":'Home'})
        mfooterMenu.push({"defaultImageIcon":'../assets/more.png',"menuL1Title":'More'})
        const pathName = location.pathname.replace(/\//g, '')
        let menuL1DeepLink;
        if(pathName!="") {
            menuL1DeepLink= mainMenu?.filter(item=>item.menuL1Title.toLowerCase().replace(/ /g, "")==pathName)[0]?.menuL1DeeplinkUrl
        }
        else{
            menuL1DeepLink= mainMenu[0]?.menuL1DeeplinkUrl
        }
        return state.set('data',fromJS({
            mainData:mainMenu,
            tvSubMenu:tvSubMenu,
            webSubMenuData:webSubMenu,
            menuL1DeepLinkData:menuL1DeepLink,
            mfooterData:mfooterMenu
        }))
    },
    [constants.MENU_ERROR]: (state, payload) => {
        return state.set('menuData', fromJS(payload))
    }   
};

const menuReducer = createReducerFromObject(reducerFunctions, initialState);
export default menuReducer;

