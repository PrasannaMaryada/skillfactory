import { fromJS } from 'immutable';
import * as constants  from '../actions/Constants.js';
import { createReducerFromObject } from '../Utils/reducerUtils';

export const initialState = fromJS({
    data:{
        railsData: {},
        bannerData:{},
    },
    railErr:{}    
});

const reducerFunctions = {
    [constants.RAIL_SUCCESS]: (state, payload) => {
        
        let bannerImages = payload?.filter((rail) => rail.existing_asset.count > 0 &&
            rail.existing_asset_type == "Banner")[0]?.existing_asset.existing_asset.map(item=>item.images[0])
            .filter(image=>image.imagetype=='Poster').map(image=>image.imageurl);

        let rails = payload?.filter(rail => rail.existing_asset.count > 0 && rail.existing_asset_type != "Banner")
        
        const data={bannerData:bannerImages,railsData:rails}

        return state.set('data',fromJS(data))
    },
    [constants.RAIL_ERROR]: (state, payload) => {
        return state.set('railErr', fromJS(payload))
    }   
};

const railReducer = createReducerFromObject(reducerFunctions, initialState);
export default railReducer;



