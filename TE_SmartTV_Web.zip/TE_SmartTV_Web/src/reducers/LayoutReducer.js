import { fromJS } from 'immutable';
import * as constants  from '../actions/Constants.js';
import { createReducerFromObject } from '../Utils/reducerUtils';

export const initialState = fromJS({
    layoutData: {}    
});

const reducerFunctions = {
    [constants.LAYOUT_SUCCESS]: (state, payload) => {
        // console.log("payload",payload);
        return state.set('layoutData', fromJS(payload))
    },
    [constants.LAYOUT_ERROR]: (state, payload) => {
        return state.set('layoutData', fromJS(payload))
    }   
};

const layoutReducer = createReducerFromObject(reducerFunctions, initialState);
export default layoutReducer;



