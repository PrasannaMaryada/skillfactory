import { fromJS } from 'immutable';
import * as constants  from '../actions/Constants.js';
import { createReducerFromObject } from '../Utils/reducerUtils';

export const initialState = fromJS({
    bannerData: {}    
});

const reducerFunctions = {
    [constants.BANNER_SUCCESS]: (state, payload) => {
        return state.set('bannerData', fromJS(payload))
    },
    [constants.BANNER_ERROR]: (state, payload) => {
        return state.set('bannnerData', fromJS(payload))
    }   
};

const bannerReducer = createReducerFromObject(reducerFunctions, initialState);
export default bannerReducer;

