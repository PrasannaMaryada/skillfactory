import { fromJS } from 'immutable';
import * as constants  from '../actions/Constants.js';
import { createReducerFromObject } from '../Utils/reducerUtils';

export const initialState = fromJS({
    logoData: {}    
});

const reducerFunctions = {
    [constants.LOGO_SUCCESS]: (state, payload) => {
        let logoImage = payload?.filter(item => item.default_logo=="1")[0]
        return state.set('logoData', fromJS(logoImage))
    },
    [constants.LOGO_ERROR]: (state, payload) => {
        return state.set('logoData', fromJS(payload))
    }   
};

const logoReducer = createReducerFromObject(reducerFunctions, initialState);
export default logoReducer;



