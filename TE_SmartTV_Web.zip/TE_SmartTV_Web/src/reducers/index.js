import { combineReducers } from 'redux';

import BannerReducer from './BannerReducer';
import LogoReducer from './LogoReducer';
import MenuReducer from './MenuReducer';
import RailReducer from './RailReducer';
import LayoutReducer from './LayoutReducer';

export default function createReducer(asyncReducer) {
    const appReducer = combineReducers({
        BannerReducer,
        LogoReducer,
        MenuReducer,
        RailReducer,
        LayoutReducer,
        ...asyncReducer
    });

    return (state, action) => appReducer(state, action);
}