import { call, takeEvery } from 'redux-saga/effects';
import * as constants from "../actions/Constants";
import { store } from '../Router.js';
import request from '../Utils/request';
import { bannerApiSuccess, bannerApiError } from '../actions/BannerAction';
import { BASE_URL, URL } from '../constant/environment'


export function* getBannerContent() {
    try {
        yield call(request,BASE_URL.SERVER_CMS+URL.BANNER_URL,
            {
                method: "GET",
            },
            {
                onSuccess(response) {
                    store.dispatch(bannerApiSuccess(response))
                },
                onError(error) {
                    store.dispatch(bannerApiError(error))
                },
            }, true);
    } catch (error) {
    }
}


export default function* BannerSaga() {
    yield takeEvery(constants.BANNER_CONTENT, getBannerContent)
}