import { call, takeEvery } from 'redux-saga/effects';
import * as constants from "../actions/Constants";
import { store } from '../Router.js';
import request from '../Utils/request';
import { layoutApiSuccess, layoutApiError } from '../actions/LayoutAction';
import { BASE_URL, URL } from '../constant/environment'
import { railApi } from '../actions/RailAction';

export function* getLayoutContent({payload}) {
    try {
        yield call(request,
            BASE_URL.SERVER_CMS+URL.LAYOUT_URL+ `/${payload.substr(payload.indexOf('/')+1)}`,
            {
                method: "GET",
            },
            {
                onSuccess(response) {
                    store.dispatch(layoutApiSuccess(response))
                    let railIds = response?.rail_id;
                    railIds = railIds > 0 ? railIds.join() : railIds;
                    railIds && store.dispatch(railApi(railIds));
                },
                onError(error) {
                    store.dispatch(layoutApiError(error))
                },
            }, true);
    } catch (error) {
    }
}

export default function* LayoutSaga() {
    yield takeEvery(constants.LAYOUT_CONTENT, getLayoutContent)
}