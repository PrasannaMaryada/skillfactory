import { call, takeEvery } from 'redux-saga/effects';
import * as constants from "../actions/Constants";
import { store } from '../Router.js';
import request from '../Utils/request';
import { menuApiSuccess, menuApiError } from '../actions/MenuAction';
import { BASE_URL, URL } from '../constant/environment'


export function* getMenuContent() {
    try {
        yield call(request,BASE_URL.SERVER_CMS+URL.MENU_URL,
            {
                method: "GET",
            },
            {
                onSuccess(response) {
                    let data = response.results;
                    if(!data.length){
                        store.dispatch(menuApiError(error))
                    }
                    else{
                        store.dispatch(menuApiSuccess(data))
                    }
                },
                onError(error) {
                    store.dispatch(menuApiError(error))
                },
            }, true);
    } catch (error) {
    }
}


export default function* MenuSaga() {
    yield takeEvery(constants.MENU_CONTENT, getMenuContent)
}