import { call, takeEvery } from 'redux-saga/effects';
import * as constants from "../actions/Constants";
import { store } from '../Router.js';
import request from '../Utils/request';
import { railApiSuccess, railApiError } from '../actions/RailAction';
import { BASE_URL, URL } from '../constant/environment'


export function* getRailContent({payload}) {
    try {
        yield call(request,BASE_URL.SERVER_CMS+URL.RAIL_URL+`?id=${payload}`,
            {
                method: "GET",
            },
            {
                onSuccess(response) {
                    let data = response.results;
                    if(!data.length){
                        store.dispatch(railApiError("No data found!"))
                    }
                    else{
                        store.dispatch(railApiSuccess(data))
                    }
                },
                onError(error) {
                    store.dispatch(railApiError(error))
                },
            }, true);
    } catch (error) {
    }
}


export default function* RailSaga() {
    yield takeEvery(constants.RAIL_CONTENT, getRailContent)
}