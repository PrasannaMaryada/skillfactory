import { call, takeEvery } from 'redux-saga/effects';
import * as constants from "../actions/Constants";
import { store } from '../Router.js';
import request from '../Utils/request';
import { logoApiSuccess, logoApiError } from '../actions/LogoAction';
import { BASE_URL, URL } from '../constant/environment'


export function* getLogoContent() {
    try {
        yield call(request,BASE_URL.SERVER_CMS+URL.LOGO_URL,
            {
                method: "GET",
            },
            {
                onSuccess(response) {
                    let data = response.results;
                    if(!data.length){
                        store.dispatch(logoApiError(error))
                    }
                    else{
                        store.dispatch(logoApiSuccess(data))
                    }
                },
                onError(error) {
                    store.dispatch(logoApiError(error))
                },
            }, true);
    } catch (error) {
    }
}


export default function* LogoSaga() {
    yield takeEvery(constants.LOGO_CONTENT, getLogoContent)
}