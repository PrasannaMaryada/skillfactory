const path = require('path');
const webpack = require('webpack');

const sourcePath = path.join(__dirname, 'src');
const TerserPlugin = require("terser-webpack-plugin");

const config = {
  mode: 'production',
  entry: ['babel-polyfill', path.resolve(sourcePath, 'index.js')],
  output: {
     path: path.join(__dirname, '/public/'),
     filename: 'bundle.js'
  },
  resolve: {
    extensions: ['.js', '.jsx'],
    modules: [
      sourcePath,
      path.resolve(__dirname, 'node_modules'),
      // yarn-workspaces
      path.resolve(__dirname, '../../node_modules')
    ]
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: [
          'babel-loader'
        ],
        include: sourcePath
      },
      {
        test: /\.css$/,
        use: ["style-loader", "css-loader"],
      }
    ],
  },
  optimization: {
    minimize: true,
    minimizer: [new TerserPlugin()],
  },
}


module.exports = config;
