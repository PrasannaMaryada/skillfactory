module.exports = {
    testRegex: "(src|server)/.*\\.test\\.js$",
    moduleFileExtensions: ["js", "jsx", "json"],
    collectCoverageFrom: [
      "src/**/*.{js,jsx,mjs}",
      "!src/index.js", 
      "!src/reportWebVitals.js", 
      "!src/setUpTests.js", 
      "!src/**/index.js"
    ],
    transform: {
      ".+\\.(css|styl|less|sass|scss|png|jpg|ttf|woff|woff2|svg)$":
        "jest-transform-stub",
      "^.+\\.(js|jsx)?$": "babel-jest",
    },
    testEnvironment: 'jsdom',
    transformIgnorePatterns: ["<rootDir>/node_modules/"],
    setupFilesAfterEnv: [
      "@testing-library/jest-dom/extend-expect",
      "@testing-library/jest-dom",
      "<rootDir>/src/setupTests.js"
    ],
  };
  